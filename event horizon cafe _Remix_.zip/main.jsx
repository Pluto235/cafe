// Event Horizon Café — main page (B-direction, tweakable)
const { useState: useS, useEffect: useE, useMemo: useM, useRef: useR } = React;

// ── color palettes ──────────────────────────────────────────────
const PALETTES = {
  void:   { ink:'#050811', ink2:'#0a0e1c', text:'#eae3d2', dim:'#6f6c5e', accent:'#d99757' }, // 墨黑
  deep:   { ink:'#040b1f', ink2:'#0a1530', text:'#e7e0c8', dim:'#5e6a85', accent:'#e9b86a' }, // 深蓝
  violet: { ink:'#0d0b22', ink2:'#161333', text:'#ebe1f0', dim:'#766c8a', accent:'#c9a3ec' }, // 深紫
  warm:   { ink:'#0e0a14', ink2:'#1a1325', text:'#f3e7c7', dim:'#85735c', accent:'#f0b56a' }, // 暖夜
  day:    { ink:'#f4e3b1', ink2:'#ead49a', text:'#3a2613', dim:'#8a6d39', accent:'#b06b1c' }, // 白天 · 暖黄
};

const FONT_SETS = {
  classic: { sans:'"Noto Serif SC", serif', italic:'"EB Garamond", serif', mono:'"JetBrains Mono", monospace', label:'宋体 + Garamond + Mono' },
  modern:  { sans:'"Noto Sans SC", sans-serif', italic:'"Cormorant Garamond", serif', mono:'"IBM Plex Mono", monospace', label:'黑体 + Cormorant + Plex' },
  paper:   { sans:'"Noto Serif SC", serif', italic:'"Cormorant Garamond", serif', mono:'"Spectral", serif', label:'全衬线 / 学术诗意' },
};

// ── Tweaks defaults (HOST WILL REWRITE THIS BLOCK) ──────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "void",
  "fontSet": "classic",
  "hero": "blackhole",
  "density": 1.0,
  "shooting": 1.0,
  "dark": true,
  "showStars": true
}/*EDITMODE-END*/;

// ── Hero · Black hole / accretion disk ──────────────────────────
function HeroBlackHole({ p }) {
  return (
    <div style={{ position:'relative', width: 460, height: 460 }}>
      <svg viewBox="0 0 460 460" style={{ width:'100%', height:'100%' }}>
        <defs>
          <radialGradient id="bh-hole" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#000" />
            <stop offset="60%" stopColor="#000" />
            <stop offset="80%" stopColor={p.accent + '66'} />
            <stop offset="100%" stopColor={p.accent + '00'} />
          </radialGradient>
          <linearGradient id="bh-ring" x1="0" x2="1">
            <stop offset="0%" stopColor={p.text} />
            <stop offset="35%" stopColor={p.accent} />
            <stop offset="65%" stopColor={p.accent} stopOpacity="0.5" />
            <stop offset="100%" stopColor={p.text} />
          </linearGradient>
          <radialGradient id="bh-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={p.accent} stopOpacity="0.6" />
            <stop offset="100%" stopColor={p.accent} stopOpacity="0" />
          </radialGradient>
        </defs>
        <circle cx="230" cy="230" r="220" fill="url(#bh-glow)" opacity="0.5" />
        <g style={{ transformOrigin:'230px 230px', animation:'bh-spin 30s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="200" ry="44" fill="none" stroke="url(#bh-ring)" strokeWidth="3" />
        </g>
        <g style={{ transformOrigin:'230px 230px', animation:'bh-spin-rev 50s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="180" ry="36" fill="none" stroke="url(#bh-ring)" strokeWidth="2" opacity="0.6" />
        </g>
        <g style={{ transformOrigin:'230px 230px', animation:'bh-spin 80s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="160" ry="28" fill="none" stroke={p.text + '66'} strokeWidth="1" />
        </g>
        <circle cx="230" cy="230" r="100" fill="url(#bh-hole)" />
        <circle cx="230" cy="230" r="76" fill="#000" />
        <path d="M 100 230 Q 230 130 360 230" fill="none" stroke={p.text + '99'} strokeWidth="1.5" />
      </svg>
      <style>{`
        @keyframes bh-spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }
        @keyframes bh-spin-rev { from{transform:rotate(0)} to{transform:rotate(-360deg)} }
      `}</style>
      <div style={{ position:'absolute', top:8, right:-20, fontFamily: 'var(--ehc-mono)', fontSize: 10, color:p.dim, letterSpacing:'0.15em' }}>
        <div>r_s ≈ 2GM/c²</div>
        <div style={{ marginTop:4 }}>L ≃ 10³⁹ erg/s</div>
      </div>
      <div style={{ position:'absolute', bottom:30, left:-10, fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim, letterSpacing:'0.15em' }}>
        ⟶ accretion disk
      </div>
    </div>
  );
}

// ── Hero · galaxy milkshake ─────────────────────────────────────
function HeroGalaxy({ p }) {
  return (
    <div style={{ position:'relative', width:460, height:460 }}>
      <style>{`
        @keyframes gx-spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }
        @keyframes gx-spin-rev { from{transform:rotate(0)} to{transform:rotate(-360deg)} }
        @keyframes gx-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
      `}</style>
      <div style={{ position:'absolute', inset:0, animation:'gx-spin 60s linear infinite' }}>
        <svg viewBox="-230 -230 460 460" style={{ width:'100%', height:'100%', overflow:'visible' }}>
          <ellipse cx="0" cy="0" rx="210" ry="70" fill="none" stroke={p.accent + '40'} strokeDasharray="2 6" strokeWidth="0.8" />
          <circle cx="210" cy="0" r="3" fill={p.accent} />
        </svg>
      </div>
      <div style={{ position:'absolute', inset:0, animation:'gx-spin-rev 90s linear infinite' }}>
        <svg viewBox="-230 -230 460 460" style={{ width:'100%', height:'100%', overflow:'visible' }}>
          <ellipse cx="0" cy="0" rx="180" ry="220" fill="none" stroke={p.text + '30'} strokeWidth="0.6" />
          <circle cx="0" cy="220" r="2" fill={p.text} />
        </svg>
      </div>
      <div style={{ position:'absolute', left:'50%', top:'50%', transform:'translate(-50%,-50%)', animation:'gx-float 6s ease-in-out infinite' }}>
        <svg width="240" height="340" viewBox="0 0 240 340">
          <defs>
            <radialGradient id="gx-galaxy" cx="50%" cy="45%" r="55%">
              <stop offset="0%" stopColor={p.text} />
              <stop offset="20%" stopColor={p.accent} />
              <stop offset="55%" stopColor={p.accent} stopOpacity="0.5" />
              <stop offset="100%" stopColor={p.ink} stopOpacity="0" />
            </radialGradient>
            <linearGradient id="gx-glass" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={p.text + '40'} />
              <stop offset="100%" stopColor={p.text + '0a'} />
            </linearGradient>
          </defs>
          <path d="M 38 70 L 70 300 Q 70 318 88 318 L 152 318 Q 170 318 170 300 L 202 70 Z"
                fill="url(#gx-glass)" stroke={p.text + '80'} strokeWidth="1.2" />
          <ellipse cx="120" cy="72" rx="82" ry="12" fill={p.ink} opacity="0.6" />
          <g style={{ transformOrigin:'120px 180px', animation:'gx-spin 24s linear infinite' }}>
            <ellipse cx="120" cy="180" rx="80" ry="80" fill="url(#gx-galaxy)" />
            <circle cx="120" cy="180" r="14" fill={p.text} />
            <circle cx="120" cy="180" r="6" fill="#fff" />
          </g>
          <line x1="148" y1="30" x2="130" y2="310" stroke={p.accent} strokeWidth="3" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
}

// ── Hero · constellation ────────────────────────────────────────
function HeroConstellation({ p }) {
  const stars = [{x:80,y:200},{x:160,y:120},{x:240,y:180},{x:330,y:90},{x:420,y:160},{x:500,y:240},{x:380,y:280},{x:280,y:340},{x:180,y:300},{x:90,y:360}];
  const lines = [[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[8,9],[8,2],[6,4]];
  return (
    <div style={{ position:'relative', width:'100%', height:460 }}>
      <style>{`@keyframes cn-tw { 0%,100%{opacity:0.5} 50%{opacity:1} }`}</style>
      <svg viewBox="0 0 600 460" style={{ width:'100%', height:'100%' }}>
        <defs>
          <radialGradient id="cn-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={p.accent} stopOpacity="0.5" />
            <stop offset="100%" stopColor={p.accent} stopOpacity="0" />
          </radialGradient>
        </defs>
        {lines.map(([a,b],i)=>(
          <line key={i} x1={stars[a].x} y1={stars[a].y} x2={stars[b].x} y2={stars[b].y}
                stroke={p.text} strokeWidth="0.6" opacity="0.4" strokeDasharray="2 4" />
        ))}
        {stars.map((s,i)=>(
          <g key={i}>
            <circle cx={s.x} cy={s.y} r="14" fill="url(#cn-glow)" />
            <circle cx={s.x} cy={s.y} r={i%3===0?4:2.5} fill={p.accent}
                    style={{ animation:`cn-tw ${3+i*0.3}s ease-in-out infinite`, animationDelay:`${i*0.2}s` }} />
          </g>
        ))}
        <g transform="translate(260, 130)" opacity="0.92">
          <path d="M 20 30 L 30 130 Q 30 140 40 140 L 70 140 Q 80 140 80 130 L 90 30 Z"
                fill={p.ink2} stroke={p.text} strokeWidth="1.2" />
          <ellipse cx="55" cy="32" rx="35" ry="6" fill={p.text} />
          <ellipse cx="55" cy="32" rx="32" ry="4.5" fill={p.accent} opacity="0.7" />
          <line x1="68" y1="14" x2="60" y2="135" stroke={p.accent} strokeWidth="2" strokeLinecap="round" />
          <circle cx="55" cy="92" r="2" fill={p.accent} />
        </g>
      </svg>
    </div>
  );
}

// ── starfield ───────────────────────────────────────────────────
function Starfield({ p, density, shooting, enabled }) {
  const ref = useR(null);
  useE(() => {
    if (!enabled) return;
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    let raf, w, h, stars=[], shoots=[];
    const dpr = Math.min(window.devicePixelRatio||1, 2);
    function resize() {
      w = c.clientWidth; h = c.clientHeight;
      c.width = w*dpr; c.height = h*dpr;
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const n = Math.floor(w*h/2200 * density);
      stars = Array.from({length: n}, () => ({
        x: Math.random()*w, y: Math.random()*h,
        r: Math.random()*1.1 + 0.2, a: Math.random()*0.7 + 0.3,
        tw: Math.random()*0.02 + 0.005, ph: Math.random()*Math.PI*2,
      }));
    }
    function tick(t) {
      ctx.clearRect(0,0,w,h);
      for (const s of stars) {
        const a = s.a*(0.6+0.4*Math.sin(t*s.tw+s.ph));
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
        ctx.fillStyle = `${p.text}${Math.round(a*255).toString(16).padStart(2,'0')}`;
        ctx.fill();
      }
      if (Math.random() < 0.003 * shooting) {
        shoots.push({ x: Math.random()*w*0.7+w*0.1, y: Math.random()*h*0.4,
          vx: 4+Math.random()*3, vy: 1.2+Math.random()*1, life:0, max: 60+Math.random()*30 });
      }
      shoots = shoots.filter(sh => {
        sh.life++;
        const head = sh.life/sh.max;
        if (head>=1) return false;
        const len = 80;
        const tx = sh.x+sh.vx*sh.life, ty = sh.y+sh.vy*sh.life;
        const grd = ctx.createLinearGradient(tx,ty,tx-len,ty-len*sh.vy/sh.vx);
        grd.addColorStop(0, `${p.text}${Math.round(0.9*(1-head)*255).toString(16).padStart(2,'0')}`);
        grd.addColorStop(1, p.text+'00');
        ctx.strokeStyle = grd; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(tx,ty); ctx.lineTo(tx-len, ty-len*sh.vy/sh.vx); ctx.stroke();
        return true;
      });
      raf = requestAnimationFrame(tick);
    }
    resize();
    const ro = new ResizeObserver(resize); ro.observe(c);
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [p, density, shooting, enabled]);
  if (!enabled) return null;
  return <canvas ref={ref} style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }} />;
}

// ── menu row ────────────────────────────────────────────────────
function MenuRow({ p, item, idx, onAdd }) {
  const [hover, setHover] = useS(false);
  return (
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
         style={{ display:'grid', gridTemplateColumns:'60px 1.4fr 1fr 100px 130px',
                  gap: 32, alignItems:'center', padding:'28px 0',
                  borderBottom:`1px solid ${p.dim}40`,
                  background: hover ? `${p.accent}10` : 'transparent',
                  paddingLeft: hover ? 16 : 0,
                  transition:'background .25s, padding .25s' }}>
      <div style={{ fontFamily:'var(--ehc-mono)', fontSize:12, color:p.dim, letterSpacing:'0.15em' }}>
        {String(idx+1).padStart(2,'0')} /
      </div>
      <div>
        <div style={{ fontFamily:'var(--ehc-sans)', fontSize:26, color:p.text, letterSpacing:'0.04em' }}>{item.cn}</div>
        <div style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', fontSize:14, color:p.accent, marginTop:4 }}>{item.en}</div>
      </div>
      <div style={{ fontSize:12, lineHeight:1.8, color:p.dim, fontFamily:'var(--ehc-sans)' }}>{item.sub}</div>
      <div style={{ height:56, opacity: hover?1:0.35, transition:'opacity .25s' }}>
        <div style={{ display:'flex', gap:4, alignItems:'flex-end', height:'100%' }}>
          {Object.entries(item.spectrum).map(([k,v])=>(
            <div key={k} title={k} style={{ flex:1, height:`${v*100}%`, background:p.accent, opacity: 0.6+v*0.4 }} />
          ))}
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'flex-end', gap:14 }}>
        <span style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', fontSize:22, color:p.accent }}>¥{item.price}</span>
        <button onClick={()=>onAdd(item)} style={{
          background:'transparent', border:`1px solid ${p.accent}`, color:p.accent,
          padding:'8px 14px', cursor:'pointer', fontFamily:'var(--ehc-mono)',
          fontSize:11, letterSpacing:'0.2em',
        }}>+ ADD</button>
      </div>
    </div>
  );
}

// ── main page ───────────────────────────────────────────────────
// 默认按时间判断：早 6 点 — 晚 6 点为白天
function isDaytimeNow() {
  const h = new Date().getHours();
  return h >= 6 && h < 18;
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // 首次加载：若用户未手动切换过，则根据时间决定昼/夜
  useE(() => {
    if (localStorage.getItem('ehc-mode-manual') !== '1') {
      const shouldBeDark = !isDaytimeNow();
      if (t.dark !== shouldBeDark) setTweak('dark', shouldBeDark);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleMode = () => {
    localStorage.setItem('ehc-mode-manual', '1');
    setTweak('dark', !t.dark);
  };

  // 夜晚模式使用 palette 选择；白天模式固定为暖黄 day 调色。
  const p = t.dark ? (PALETTES[t.palette] || PALETTES.void) : PALETTES.day;
  const f = FONT_SETS[t.fontSet] || FONT_SETS.classic;
  const today = window.EHC_TODAY;
  const [cart, setCart] = useS([]);
  const [pickup, setPickup] = useS('20:00');
  const [submitted, setSubmitted] = useS(false);
  const [wishText, setWishText] = useS('');
  const [wishes, setWishes] = useS(window.EHC_WISHES);
  const total = cart.reduce((s,c)=>s+c.price*c.qty,0);
  const add = (it) => setCart(prev => {
    const f = prev.find(x=>x.id===it.id);
    return f ? prev.map(x=>x.id===it.id?{...x,qty:x.qty+1}:x) : [...prev, {...it, qty:1}];
  });

  // expose font vars on root
  useE(() => {
    document.documentElement.style.setProperty('--ehc-sans', f.sans);
    document.documentElement.style.setProperty('--ehc-italic', f.italic);
    document.documentElement.style.setProperty('--ehc-mono', f.mono);
    document.body.style.background = p.ink;
  }, [f, p]);

  const Hero = t.hero === 'galaxy' ? HeroGalaxy : t.hero === 'constellation' ? HeroConstellation : HeroBlackHole;

  return (
    <div style={{
      background: p.ink, color: p.text, fontFamily:'var(--ehc-sans)',
      minHeight:'100vh', position:'relative',
    }}>
      {/* HERO */}
      <section style={{ position:'relative', minHeight: '100vh', display:'grid',
                        gridTemplateColumns:'1fr 1fr', alignItems:'center', padding:'0 80px', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, opacity: t.dark?1:0.3 }}>
          <Starfield p={p} density={t.density} shooting={t.shooting} enabled={t.showStars} />
        </div>
        {/* nav */}
        <nav style={{ position:'absolute', top:0, left:0, right:0, padding:'30px 80px',
                       display:'flex', justifyContent:'space-between', alignItems:'center',
                       fontFamily:'var(--ehc-mono)', fontSize:11, letterSpacing:'0.25em', zIndex: 5 }}>
          <div style={{ color:p.text }}>EHC<span style={{ color:p.accent, margin:'0 6px' }}>·</span>事件视界</div>
          <div style={{ display:'flex', gap:32, color:p.dim }}>
            {[['MENU','#m'],['ORDER','#o'],['WISHES','#w'],['ABOUT','#a']].map(([n,h])=>(
              <a key={n} href={h} style={{ color:'inherit', textDecoration:'none' }}
                 onMouseEnter={e=>e.currentTarget.style.color=p.accent}
                 onMouseLeave={e=>e.currentTarget.style.color=p.dim}>[ {n} ]</a>
            ))}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:18 }}>
            <button onClick={toggleMode}
              aria-label={t.dark ? '切换到白天模式' : '切换到夜晚模式'}
              title={t.dark ? '切换到白天模式 / Day' : '切换到夜晚模式 / Night'}
              style={{
                background:'transparent', border:`1px solid ${p.dim}`,
                color: p.text, cursor:'pointer',
                width:34, height:34, borderRadius:'50%',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                padding:0, transition:'border-color .25s, color .25s',
              }}
              onMouseEnter={e=>{ e.currentTarget.style.borderColor = p.accent; e.currentTarget.style.color = p.accent; }}
              onMouseLeave={e=>{ e.currentTarget.style.borderColor = p.dim; e.currentTarget.style.color = p.text; }}>
              {t.dark ? (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="4" />
                  <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
                </svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              )}
            </button>
            <span style={{ color:p.dim }}>{today.dateEn.toUpperCase()}</span>
          </div>
        </nav>

        <div style={{ position:'relative', zIndex:2 }}>
          <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.accent, letterSpacing:'0.4em', marginBottom:36 }}>
            ▸ EST. 2026 / DEPT. OF ASTRONOMY / Bldg-A 1F
          </div>
          <h1 style={{ fontFamily:'var(--ehc-sans)', fontWeight:300, fontSize:96, lineHeight:1.1, margin:0, letterSpacing:'0.02em' }}>
            一切味道<br/>
            被引向<br/>
            <span style={{ fontStyle:'italic', fontFamily:'var(--ehc-italic)', color:p.accent, fontSize:110 }}>视界。</span>
          </h1>
          <p style={{ marginTop:40, fontSize:16, lineHeight:2, color:p.dim, maxWidth:480,
                       textWrap:'pretty', borderLeft:`1px solid ${p.accent}`, paddingLeft:20 }}>
            <span style={{ fontStyle:'italic', fontFamily:'var(--ehc-italic)' }}>
              "Beyond the event horizon, even light cannot escape — only sweetness."
            </span><br/><br/>
            一家由天文系几位学生开起来的小奶昔铺。
            我们把光谱、轨道根数、吸积盘的颜色，
            都研磨进了每一杯里。
          </p>
          <div style={{ marginTop:56, display:'flex', gap:40, alignItems:'center' }}>
            <a href="#m" style={{ padding:'18px 42px', background:p.accent, color:p.ink,
                                   fontFamily:'var(--ehc-mono)', fontSize:12, letterSpacing:'0.3em',
                                   textDecoration:'none', fontWeight:600 }}>VIEW MENU →</a>
            <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.dim, letterSpacing:'0.2em' }}>
              <div>OPEN TONIGHT</div>
              <div style={{ color:p.text, marginTop:4 }}>{today.hours}</div>
            </div>
          </div>
        </div>
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center', position:'relative', zIndex:2 }}>
          <Hero p={p} />
        </div>
        <div style={{ position:'absolute', bottom:36, left:80, right:80, zIndex:3,
                       display:'flex', justifyContent:'space-between',
                       borderTop:`1px solid ${p.dim}`, paddingTop:18,
                       fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim, letterSpacing:'0.2em' }}>
          <span>FIG. 01 / SAGITTARIUS A* — INSPIRATION OF THE HOUSE</span>
          <span>SCROLL ↓</span>
          <span>SOLD: 4,176 SHAKES SINCE 2026.02</span>
        </div>
      </section>

      {/* TONIGHT */}
      <section style={{ padding:'80px', background: p.ink2, borderTop:`1px solid ${p.dim}` }}>
        <div style={{ display:'grid', gridTemplateColumns:'200px 1fr', gap:80 }}>
          <div>
            <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.accent, letterSpacing:'0.3em' }}>✦ TONIGHT'S SKY</div>
            <div style={{ marginTop:14, fontSize:36, fontFamily:'var(--ehc-sans)', fontWeight:300 }}>今夜</div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)' }}>
            {[['日落 SUNSET',today.sunset],['月相 MOON','蛾眉月 14%'],['亮点 EVENT','土星 ⇢ 月 2.4°'],['天气 SEEING','★★★ 通透']].map(([l,v],i)=>(
              <div key={i} style={{ borderLeft: i?`1px solid ${p.dim}`:'none', paddingLeft: i?28:0 }}>
                <div style={{ fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim, letterSpacing:'0.25em' }}>{l}</div>
                <div style={{ marginTop:12, fontFamily:'var(--ehc-italic)', fontStyle:'italic', fontSize:28, color:p.text }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MENU */}
      <section id="m" style={{ padding:'140px 80px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:60 }}>
          <div>
            <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.accent, letterSpacing:'0.4em' }}>
              CATALOG · §02 · MAY 2026
            </div>
            <h2 style={{ fontFamily:'var(--ehc-sans)', fontWeight:300, fontSize:72, margin:'18px 0 0', letterSpacing:'0.02em' }}>
              本月 / <span style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', color:p.accent }}>The Catalog</span>
            </h2>
          </div>
          <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.dim, letterSpacing:'0.2em', textAlign:'right' }}>
            HOVER A ROW TO READ ITS SPECTRUM<br/>悬停查看光谱
          </div>
        </div>
        <div style={{ borderTop:`1px solid ${p.dim}` }}>
          {window.EHC_MENU.map((it,i)=> <MenuRow key={it.id} p={p} item={it} idx={i} onAdd={add} />)}
        </div>
      </section>

      {/* ORDER */}
      <section id="o" style={{ padding:'140px 80px', background: p.ink2 }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:80 }}>
          <div>
            <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.accent, letterSpacing:'0.4em' }}>§03 · RESERVE</div>
            <h2 style={{ fontFamily:'var(--ehc-sans)', fontWeight:300, fontSize:64, margin:'18px 0 24px' }}>
              留一杯<br/>
              <span style={{ fontStyle:'italic', fontFamily:'var(--ehc-italic)', color:p.accent }}>in advance.</span>
            </h2>
            <p style={{ fontSize:14, lineHeight:2, color:p.dim, maxWidth:440, textWrap:'pretty' }}>
              选好奶昔与取餐时间，到店扫码确认即可。无需付定金。
              如当晚遇到特殊天象（流星雨、月掩星、行星合月），我们会在备注里附上观测建议。
            </p>
            <div style={{ marginTop:48 }}>
              <div style={{ fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim, letterSpacing:'0.3em', marginBottom:16 }}>
                PICKUP_TIME =
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', border:`1px solid ${p.dim}` }}>
                {['18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'].map((tm,i)=>(
                  <button key={tm} onClick={()=>setPickup(tm)} style={{
                    padding:'14px 0', background: pickup===tm? p.accent:'transparent',
                    color: pickup===tm? p.ink:p.text, border:'none',
                    borderRight:(i+1)%5? `1px solid ${p.dim}`:'none',
                    borderTop: i>=5? `1px solid ${p.dim}`:'none',
                    fontFamily:'var(--ehc-mono)', fontSize:12, letterSpacing:'0.1em', cursor:'pointer',
                  }}>{tm}</button>
                ))}
              </div>
            </div>
          </div>
          <div>
            <div style={{ border:`1px solid ${p.dim}`, padding:32, background: p.ink + 'cc' }}>
              <div style={{ display:'flex', justifyContent:'space-between',
                             borderBottom:`1px solid ${p.dim}`, paddingBottom:14, marginBottom:18,
                             fontFamily:'var(--ehc-mono)', fontSize:11, letterSpacing:'0.25em' }}>
                <span>// CART</span>
                <span style={{ color:p.accent }}>{cart.length} ITEM(S)</span>
              </div>
              {cart.length===0 ? (
                <div style={{ padding:'30px 0', textAlign:'center', color:p.dim,
                               fontFamily:'var(--ehc-italic)', fontStyle:'italic', fontSize:14 }}>
                  empty horizon — add a shake above.
                </div>
              ) : cart.map(c=>(
                <div key={c.id} style={{ display:'grid', gridTemplateColumns:'1fr auto auto',
                                          gap:16, padding:'10px 0', borderBottom:`1px dashed ${p.dim}` }}>
                  <div>
                    <div style={{ fontSize:16, color:p.text }}>{c.cn}</div>
                    <div style={{ fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim,
                                   letterSpacing:'0.2em', marginTop:2 }}>{c.en.toUpperCase()}</div>
                  </div>
                  <div style={{ fontFamily:'var(--ehc-mono)', color:p.accent }}>×{c.qty}</div>
                  <div style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', color:p.accent, minWidth:60, textAlign:'right' }}>¥{c.price*c.qty}</div>
                </div>
              ))}
              <div style={{ marginTop:24, display:'flex', justifyContent:'space-between',
                             alignItems:'baseline', fontFamily:'var(--ehc-mono)',
                             fontSize:11, letterSpacing:'0.25em' }}>
                <span style={{ color:p.dim }}>TOTAL =</span>
                <span style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', fontSize:32, color:p.accent, letterSpacing:0 }}>¥{total}</span>
              </div>
              <button onClick={()=>cart.length && setSubmitted(true)} disabled={!cart.length} style={{
                marginTop:22, width:'100%', padding:16,
                background: cart.length? p.accent: p.accent+'30',
                color: cart.length? p.ink: p.dim,
                border:'none', fontFamily:'var(--ehc-mono)', fontSize:12,
                letterSpacing:'0.4em', cursor: cart.length?'pointer':'not-allowed', fontWeight:600,
              }}>{submitted? `RESERVED · ${pickup} ✦` : `CONFIRM @ ${pickup}`}</button>
            </div>
          </div>
        </div>
      </section>

      {/* WISHES */}
      <section id="w" style={{ padding:'140px 80px', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, opacity:0.4 }}>
          <Starfield p={p} density={t.density*0.5} shooting={t.shooting*0.3} enabled={t.showStars} />
        </div>
        <div style={{ position:'relative', zIndex:1 }}>
          <div style={{ fontFamily:'var(--ehc-mono)', fontSize:11, color:p.accent, letterSpacing:'0.4em' }}>
            §04 · WALL OF WISHES
          </div>
          <h2 style={{ fontFamily:'var(--ehc-sans)', fontWeight:300, fontSize:64, margin:'18px 0 48px' }}>
            星愿 / <span style={{ fontFamily:'var(--ehc-italic)', fontStyle:'italic', color:p.accent }}>photons into the dark</span>
          </h2>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 2fr', gap:60 }}>
            <div>
              <textarea value={wishText} onChange={e=>setWishText(e.target.value)}
                placeholder="// 写下你想发给宇宙的一句话…"
                rows={6}
                style={{ width:'100%', background: p.ink2, border:`1px solid ${p.dim}`,
                         padding:18, color:p.text, fontFamily:'var(--ehc-sans)',
                         fontSize:14, lineHeight:1.85, outline:'none', resize:'none', boxSizing:'border-box' }} />
              <button onClick={()=>{
                if (!wishText.trim()) return;
                setWishes(w=>[{ name:'匿名', text: wishText, when:'just now' }, ...w]);
                setWishText('');
              }} style={{
                marginTop:14, padding:'12px 24px', background:'transparent',
                border:`1px solid ${p.accent}`, color:p.accent,
                fontFamily:'var(--ehc-mono)', fontSize:11, letterSpacing:'0.3em', cursor:'pointer',
              }}>SEND PHOTON →</button>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
              {wishes.slice(0,6).map((w,i)=>(
                <div key={i} style={{ borderLeft:`1px solid ${p.accent}`, paddingLeft:18, paddingBottom:8 }}>
                  <p style={{ margin:0, fontSize:13, lineHeight:1.85, color:p.text, textWrap:'pretty' }}>
                    「{w.text}」
                  </p>
                  <div style={{ marginTop:8, fontFamily:'var(--ehc-mono)', fontSize:10, color:p.dim, letterSpacing:'0.2em' }}>
                    — {w.name} · {w.when}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer id="a" style={{ padding:'60px 80px', background: p.ink, borderTop:`1px solid ${p.dim}` }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:40,
                       fontFamily:'var(--ehc-mono)', fontSize:11, letterSpacing:'0.2em', color:p.dim, lineHeight:2 }}>
          <div>
            <div style={{ color:p.accent, fontSize:14, letterSpacing:'0.3em' }}>EVENT_HORIZON_CAFÉ</div>
            <div style={{ marginTop:14 }}>EST. 2026 / RUN BY ASTRONOMY UNDERGRADS<br/>OPEN TUE–SUN UNTIL PITCH NIGHT</div>
          </div>
          <div>
            <div style={{ color:p.text }}>// ADDRESS</div>
            <div style={{ marginTop:8 }}>ASTRONOMY BLDG, 1F WEST<br/>WECHAT: ehc_observatory</div>
          </div>
          <div>
            <div style={{ color:p.text }}>// CREDITS</div>
            <div style={{ marginTop:8 }}>BUILT WITH PHOTONS &<br/>0.5g OF STARLIGHT · 2026</div>
          </div>
        </div>
      </footer>

      {/* ── TWEAKS ── */}
      <TweaksPanel title="Tweaks · 视界控制台">
        <TweakSection label="夜晚主色 / Night palette" />
        <TweakSelect value={t.palette} onChange={v=>setTweak('palette', v)}
          options={[['void','墨黑 · Void'],['deep','深蓝 · Deep'],['violet','深紫 · Violet'],['warm','暖夜 · Warm Night']]} />
        <div style={{ fontSize:10.5, lineHeight:1.5, color:'rgba(41,38,27,.55)', marginTop:-2 }}>
          白昼模式固定为暖黄调；夜晚下可在以上四色间切换。
        </div>
        <TweakSection label="字体 / Typography" />
        <TweakSelect value={t.fontSet} onChange={v=>setTweak('fontSet', v)}
          options={[['classic', FONT_SETS.classic.label],['modern', FONT_SETS.modern.label],['paper', FONT_SETS.paper.label]]} />
        <TweakSection label="首屏视觉 / Hero" />
        <TweakRadio value={t.hero} onChange={v=>setTweak('hero', v)}
          options={[['blackhole','黑洞'],['galaxy','星系'],['constellation','星座']]} />
        <TweakSection label="星空 / Starfield" />
        <TweakToggle label="显示星空" value={t.showStars} onChange={v=>setTweak('showStars', v)} />
        <TweakSlider label="星点密度" value={t.density} min={0} max={2} step={0.1}
          onChange={v=>setTweak('density', v)} />
        <TweakSlider label="流星频率" value={t.shooting} min={0} max={3} step={0.1}
          onChange={v=>setTweak('shooting', v)} />
        <TweakSection label="模式 / Mode" />
        <TweakRadio value={t.dark} onChange={v=>setTweak('dark', v)}
          options={[[true,'夜 · Night'],[false,'昼 · Day']]} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
