// Variation B · 深邃黑洞 / Deep Black Hole
// 极深底色 + 单色暖白 + 学术等宽细节；首屏是吸积盘黑洞
const { useState: useStateB, useEffect: useEffectB, useRef: useRefB } = React;

const B_INK = '#050811';
const B_INK2 = '#0a0e1c';
const B_TEXT = '#eae3d2';
const B_DIM = '#8a8678';
const B_AMBER = '#d99757';

function AccretionDisk() {
  return (
    <div style={{ position:'relative', width: 460, height: 460 }}>
      <style>{`
        @keyframes b-disk { from{transform:rotate(0)} to{transform:rotate(360deg)} }
        @keyframes b-disk-rev { from{transform:rotate(0)} to{transform:rotate(-360deg)} }
        @keyframes b-pulse { 0%,100%{opacity:0.85} 50%{opacity:1} }
      `}</style>
      <svg viewBox="0 0 460 460" style={{ width:'100%', height:'100%' }}>
        <defs>
          <radialGradient id="b-hole" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#000" />
            <stop offset="60%" stopColor="#000" />
            <stop offset="80%" stopColor="rgba(217,151,87,0.4)" />
            <stop offset="100%" stopColor="rgba(217,151,87,0)" />
          </radialGradient>
          <linearGradient id="b-ring" x1="0" x2="1">
            <stop offset="0%" stopColor="#fff5e0" />
            <stop offset="35%" stopColor="#d99757" />
            <stop offset="65%" stopColor="#9c5b2e" />
            <stop offset="100%" stopColor="#fff5e0" />
          </linearGradient>
          <radialGradient id="b-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(217,151,87,0.7)" />
            <stop offset="100%" stopColor="rgba(217,151,87,0)" />
          </radialGradient>
        </defs>
        {/* outer glow */}
        <circle cx="230" cy="230" r="220" fill="url(#b-glow)" opacity="0.5" />
        {/* photon ring 1 */}
        <g style={{ transformOrigin:'230px 230px', animation:'b-disk 30s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="200" ry="44" fill="none" stroke="url(#b-ring)" strokeWidth="3" opacity="0.85" />
        </g>
        <g style={{ transformOrigin:'230px 230px', animation:'b-disk-rev 50s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="180" ry="36" fill="none" stroke="url(#b-ring)" strokeWidth="2" opacity="0.6" />
        </g>
        <g style={{ transformOrigin:'230px 230px', animation:'b-disk 80s linear infinite' }}>
          <ellipse cx="230" cy="230" rx="160" ry="28" fill="none" stroke="rgba(255,245,224,0.4)" strokeWidth="1" />
        </g>
        {/* event horizon */}
        <circle cx="230" cy="230" r="100" fill="url(#b-hole)" />
        <circle cx="230" cy="230" r="76" fill="#000" />
        {/* lensed light */}
        <path d="M 100 230 Q 230 130 360 230" fill="none" stroke="rgba(255,245,224,0.6)" strokeWidth="1.5" />
      </svg>
      {/* labels */}
      <div style={{ position:'absolute', top: 10, right: -20, fontFamily:'"JetBrains Mono", monospace',
                     fontSize: 10, color: B_DIM, letterSpacing:'0.15em' }}>
        <div>r_s ≈ 2GM/c²</div>
        <div style={{ marginTop: 4 }}>L ≃ 10³⁹ erg/s</div>
      </div>
      <div style={{ position:'absolute', bottom: 30, left: -10, fontFamily:'"JetBrains Mono", monospace',
                     fontSize: 10, color: B_DIM, letterSpacing:'0.15em' }}>
        ⟶ accretion disk
      </div>
    </div>
  );
}

function MenuRowB({ item, idx, onAdd }) {
  const [hover, setHover] = useStateB(false);
  return (
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
         style={{
           display:'grid', gridTemplateColumns:'60px 1.4fr 1fr 100px 120px',
           gap: 32, alignItems:'center', padding:'28px 0',
           borderBottom:'1px solid rgba(234,227,210,0.12)',
           transition:'background .25s, padding .25s',
           background: hover ? 'rgba(217,151,87,0.05)' : 'transparent',
           paddingLeft: hover ? 16 : 0,
         }}>
      <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 12, color: B_DIM, letterSpacing:'0.15em' }}>
        {String(idx+1).padStart(2,'0')} /
      </div>
      <div>
        <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 26, color: B_TEXT, letterSpacing:'0.04em' }}>{item.cn}</div>
        <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 14, color: B_AMBER, marginTop: 4 }}>
          {item.en}
        </div>
      </div>
      <div style={{ fontSize: 12, lineHeight: 1.8, color: B_DIM, fontFamily:'"Noto Serif SC", serif' }}>
        {item.sub}
      </div>
      <div style={{ height: 56, opacity: hover ? 1 : 0.35, transition:'opacity .25s' }}>
        {/* mini spectrum bars */}
        <div style={{ display:'flex', gap: 4, alignItems:'flex-end', height:'100%' }}>
          {Object.entries(item.spectrum).map(([k,v]) => (
            <div key={k} style={{ flex:1, height:`${v*100}%`, background: B_AMBER, opacity: 0.7 + v*0.3 }} title={k} />
          ))}
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'flex-end', gap: 14 }}>
        <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 22, color: B_AMBER }}>¥{item.price}</span>
        <button onClick={()=>onAdd(item)} style={{
          background:'transparent', border:`1px solid ${B_AMBER}`, color: B_AMBER,
          padding:'8px 14px', cursor:'pointer', fontFamily:'"JetBrains Mono", monospace',
          fontSize: 11, letterSpacing:'0.2em',
        }}>+ ADD</button>
      </div>
    </div>
  );
}

function HomepageB() {
  const [cart, setCart] = useStateB([]);
  const [pickup, setPickup] = useStateB('20:00');
  const [submitted, setSubmitted] = useStateB(false);
  const [wishText, setWishText] = useStateB('');
  const [wishes, setWishes] = useStateB(window.EHC_WISHES);
  const today = window.EHC_TODAY;
  const total = cart.reduce((s,c)=>s+c.price*c.qty, 0);
  const add = (item) => setCart(p => {
    const f = p.find(x=>x.id===item.id);
    return f ? p.map(x=>x.id===item.id?{...x,qty:x.qty+1}:x) : [...p, {...item, qty:1}];
  });

  return (
    <div style={{ background: B_INK, color: B_TEXT, fontFamily:'"Noto Serif SC", serif',
                  width:'100%', minHeight:'100%' }}>
      {/* HERO */}
      <section style={{ position:'relative', minHeight: 1080, display:'grid',
                        gridTemplateColumns:'1fr 1fr', alignItems:'center',
                        padding:'0 80px', overflow:'hidden' }}>
        {/* nav */}
        <nav style={{
          position:'absolute', top:0, left:0, right:0,
          padding:'30px 80px', display:'flex', justifyContent:'space-between', alignItems:'center',
          fontFamily:'"JetBrains Mono", monospace', fontSize: 11, letterSpacing:'0.25em',
        }}>
          <div style={{ color: B_TEXT }}>EHC<span style={{ color: B_AMBER }}>·</span>事件视界</div>
          <div style={{ display:'flex', gap: 32, color: B_DIM }}>
            <a style={{ color:'inherit', textDecoration:'none' }} href="#m">[ MENU ]</a>
            <a style={{ color:'inherit', textDecoration:'none' }} href="#o">[ ORDER ]</a>
            <a style={{ color:'inherit', textDecoration:'none' }} href="#w">[ WISHES ]</a>
            <a style={{ color:'inherit', textDecoration:'none' }} href="#a">[ ABOUT ]</a>
          </div>
          <div style={{ color: B_DIM }}>{today.dateEn.toUpperCase()}</div>
        </nav>

        <div>
          <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_AMBER,
                        letterSpacing:'0.4em', marginBottom: 36 }}>
            ▸ EST. 2026 / DEPT. OF ASTRONOMY / Bldg-A 1F
          </div>
          <h1 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 300, fontSize: 96,
                       lineHeight: 1.1, margin:0, letterSpacing:'0.02em' }}>
            一切味道<br/>
            被引向<br/>
            <span style={{ fontStyle:'italic', fontFamily:'"EB Garamond", serif',
                           color: B_AMBER, fontSize: 110 }}>视界。</span>
          </h1>
          <p style={{ marginTop: 40, fontSize: 16, lineHeight: 2, color: B_DIM,
                       maxWidth: 480, textWrap:'pretty', borderLeft:`1px solid ${B_AMBER}`, paddingLeft: 20 }}>
            <span style={{ fontStyle:'italic', fontFamily:'"EB Garamond", serif' }}>
              "Beyond the event horizon, even light cannot escape — only sweetness."
            </span><br/><br/>
            一家由天文系几位研究生开起来的小奶昔铺。
            我们把光谱、轨道根数、吸积盘的颜色，
            都研磨进了每一杯里。
          </p>
          <div style={{ marginTop: 56, display:'flex', gap: 40, alignItems:'center' }}>
            <a href="#m" style={{
              padding:'18px 42px', background: B_AMBER, color: B_INK,
              fontFamily:'"JetBrains Mono", monospace', fontSize: 12, letterSpacing:'0.3em',
              textDecoration:'none', fontWeight: 600,
            }}>VIEW MENU →</a>
            <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_DIM, letterSpacing:'0.2em' }}>
              <div>OPEN TONIGHT</div>
              <div style={{ color: B_TEXT, marginTop: 4 }}>{today.hours}</div>
            </div>
          </div>
        </div>
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center' }}>
          <AccretionDisk />
        </div>

        {/* baseline */}
        <div style={{ position:'absolute', bottom: 36, left: 80, right: 80,
                      display:'flex', justifyContent:'space-between',
                      borderTop:`1px solid ${B_DIM}`, paddingTop: 18,
                      fontFamily:'"JetBrains Mono", monospace', fontSize: 10,
                      color: B_DIM, letterSpacing:'0.2em' }}>
          <span>FIG. 01 / SAGITTARIUS A* — INSPIRATION OF THE HOUSE</span>
          <span>SCROLL ↓</span>
          <span>SOLD: 4,176 SHAKES SINCE 2026.02</span>
        </div>
      </section>

      {/* TONIGHT */}
      <section style={{ padding:'80px', background: B_INK2, borderTop:`1px solid ${B_DIM}` }}>
        <div style={{ display:'grid', gridTemplateColumns:'200px 1fr', gap: 80 }}>
          <div>
            <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_AMBER, letterSpacing:'0.3em' }}>
              ✦ TONIGHT'S SKY
            </div>
            <div style={{ marginTop: 14, fontSize: 36, fontFamily:'"Noto Serif SC", serif', fontWeight: 300 }}>
              今夜
            </div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)' }}>
            {[
              ['日落 SUNSET', today.sunset],
              ['月相 MOON', '蛾眉月 14%'],
              ['亮点 EVENT', '土星 ⇢ 月 2.4°'],
              ['天气 SEEING', '★★★ 通透'],
            ].map(([l,v], i) => (
              <div key={i} style={{ borderLeft: i?`1px solid ${B_DIM}`:'none', paddingLeft: i? 28 : 0 }}>
                <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 10,
                              color: B_DIM, letterSpacing:'0.25em' }}>{l}</div>
                <div style={{ marginTop: 12, fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                              fontSize: 28, color: B_TEXT }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MENU */}
      <section id="m" style={{ padding:'140px 80px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom: 60 }}>
          <div>
            <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_AMBER, letterSpacing:'0.4em' }}>
              CATALOG · §02 · MAY 2026
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 300, fontSize: 72,
                         margin:'18px 0 0', letterSpacing:'0.02em' }}>
              本月 / <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: B_AMBER }}>The Catalog</span>
            </h2>
          </div>
          <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11,
                        color: B_DIM, letterSpacing:'0.2em', textAlign:'right' }}>
            HOVER A ROW TO READ ITS SPECTRUM<br/>
            悬停查看光谱
          </div>
        </div>
        <div style={{ borderTop:`1px solid ${B_DIM}` }}>
          {window.EHC_MENU.map((it,i) => <MenuRowB key={it.id} item={it} idx={i} onAdd={add} />)}
        </div>
      </section>

      {/* ORDER */}
      <section id="o" style={{ padding:'140px 80px', background: B_INK2 }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 80 }}>
          <div>
            <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_AMBER, letterSpacing:'0.4em' }}>
              §03 · RESERVE
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 300, fontSize: 64,
                         margin:'18px 0 24px' }}>
              留一杯<br/>
              <span style={{ fontStyle:'italic', fontFamily:'"EB Garamond", serif', color: B_AMBER }}>
                in advance.
              </span>
            </h2>
            <p style={{ fontSize: 14, lineHeight: 2, color: B_DIM, maxWidth: 440, textWrap:'pretty' }}>
              选好奶昔与取餐时间，到店扫码确认即可。无需付定金。
              如当晚遇到特殊天象（流星雨、月掩星、行星合月），我们会在备注里附上观测建议。
            </p>
            <div style={{ marginTop: 48 }}>
              <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 10, color: B_DIM,
                            letterSpacing:'0.3em', marginBottom: 16 }}>
                PICKUP_TIME =
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap: 0,
                             border:`1px solid ${B_DIM}` }}>
                {['18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00'].map((t,i)=>(
                  <button key={t} onClick={()=>setPickup(t)} style={{
                    padding: '14px 0', background: pickup===t? B_AMBER : 'transparent',
                    color: pickup===t? B_INK : B_TEXT,
                    border:'none',
                    borderRight: (i+1)%5? `1px solid ${B_DIM}`:'none',
                    borderTop: i>=5? `1px solid ${B_DIM}`:'none',
                    fontFamily:'"JetBrains Mono", monospace', fontSize: 12,
                    letterSpacing:'0.1em', cursor:'pointer',
                  }}>{t}</button>
                ))}
              </div>
            </div>
          </div>
          <div>
            <div style={{ border:`1px solid ${B_DIM}`, padding: 32 }}>
              <div style={{ display:'flex', justifyContent:'space-between',
                             borderBottom:`1px solid ${B_DIM}`, paddingBottom: 14, marginBottom: 18,
                             fontFamily:'"JetBrains Mono", monospace', fontSize: 11, letterSpacing:'0.25em' }}>
                <span>// CART</span>
                <span style={{ color: B_AMBER }}>{cart.length} ITEM(S)</span>
              </div>
              {cart.length === 0 ? (
                <div style={{ padding:'30px 0', textAlign:'center', color: B_DIM,
                               fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 14 }}>
                  empty horizon — add a shake above.
                </div>
              ) : (
                cart.map(c => (
                  <div key={c.id} style={{ display:'grid', gridTemplateColumns:'1fr auto auto',
                                            gap: 16, padding:'10px 0',
                                            borderBottom:`1px dashed ${B_DIM}` }}>
                    <div>
                      <div style={{ fontSize: 16, color: B_TEXT }}>{c.cn}</div>
                      <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 10,
                                     color: B_DIM, letterSpacing:'0.2em', marginTop: 2 }}>{c.en.toUpperCase()}</div>
                    </div>
                    <div style={{ fontFamily:'"JetBrains Mono", monospace', color: B_AMBER }}>×{c.qty}</div>
                    <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                   color: B_AMBER, minWidth: 60, textAlign:'right' }}>¥{c.price*c.qty}</div>
                  </div>
                ))
              )}
              <div style={{ marginTop: 24, display:'flex', justifyContent:'space-between',
                             alignItems:'baseline', fontFamily:'"JetBrains Mono", monospace',
                             fontSize: 11, letterSpacing:'0.25em' }}>
                <span style={{ color: B_DIM }}>TOTAL =</span>
                <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 32,
                                color: B_AMBER, letterSpacing:0 }}>¥{total}</span>
              </div>
              <button onClick={()=>cart.length && setSubmitted(true)} disabled={!cart.length} style={{
                marginTop: 22, width:'100%', padding: 16,
                background: cart.length? B_AMBER:'rgba(217,151,87,0.15)',
                color: cart.length? B_INK : B_DIM,
                border:'none', fontFamily:'"JetBrains Mono", monospace',
                fontSize: 12, letterSpacing:'0.4em', cursor: cart.length?'pointer':'not-allowed',
                fontWeight: 600,
              }}>{submitted? `RESERVED · ${pickup} ✦` : `CONFIRM @ ${pickup}`}</button>
            </div>
          </div>
        </div>
      </section>

      {/* WISHES */}
      <section id="w" style={{ padding:'140px 80px' }}>
        <div style={{ fontFamily:'"JetBrains Mono", monospace', fontSize: 11, color: B_AMBER, letterSpacing:'0.4em' }}>
          §04 · WALL OF WISHES
        </div>
        <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 300, fontSize: 64,
                     margin:'18px 0 48px' }}>
          星愿 / <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: B_AMBER }}>photons into the dark</span>
        </h2>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 2fr', gap: 60 }}>
          <div>
            <textarea value={wishText} onChange={e=>setWishText(e.target.value)}
              placeholder="// 写下你想发给宇宙的一句话…"
              rows={6}
              style={{ width:'100%', background: B_INK2, border:`1px solid ${B_DIM}`,
                       padding: 18, color: B_TEXT, fontFamily:'"Noto Serif SC", serif',
                       fontSize: 14, lineHeight: 1.85, outline:'none', resize:'none',
                       boxSizing:'border-box' }} />
            <button onClick={()=>{
              if (!wishText.trim()) return;
              setWishes(w => [{ name:'匿名', text: wishText, when:'just now'}, ...w]);
              setWishText('');
            }} style={{
              marginTop: 14, padding:'12px 24px', background:'transparent',
              border:`1px solid ${B_AMBER}`, color: B_AMBER,
              fontFamily:'"JetBrains Mono", monospace', fontSize: 11, letterSpacing:'0.3em', cursor:'pointer',
            }}>SEND PHOTON →</button>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 16 }}>
            {wishes.slice(0,6).map((w,i) => (
              <div key={i} style={{ borderLeft:`1px solid ${B_AMBER}`, paddingLeft: 18, paddingBottom: 8 }}>
                <p style={{ margin:0, fontSize: 13, lineHeight: 1.85, color: B_TEXT, textWrap:'pretty' }}>
                  「{w.text}」
                </p>
                <div style={{ marginTop: 8, fontFamily:'"JetBrains Mono", monospace', fontSize: 10,
                              color: B_DIM, letterSpacing:'0.2em' }}>
                  — {w.name} · {w.when}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer id="a" style={{ padding:'60px 80px', background:'#020308', borderTop:`1px solid ${B_DIM}` }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 40,
                       fontFamily:'"JetBrains Mono", monospace', fontSize: 11, letterSpacing:'0.2em',
                       color: B_DIM, lineHeight: 2 }}>
          <div>
            <div style={{ color: B_AMBER, fontSize: 14, letterSpacing:'0.3em' }}>EVENT_HORIZON_CAFÉ</div>
            <div style={{ marginTop: 14 }}>EST. 2026 / RUN BY 4 GRAD STUDENTS<br/>OPEN TUE–SUN UNTIL PITCH NIGHT</div>
          </div>
          <div>
            <div style={{ color: B_TEXT }}>// ADDRESS</div>
            <div style={{ marginTop: 8 }}>ASTRONOMY BLDG, 1F WEST<br/>WECHAT: ehc_observatory</div>
          </div>
          <div>
            <div style={{ color: B_TEXT }}>// CREDITS</div>
            <div style={{ marginTop: 8 }}>BUILT WITH PHOTONS &<br/>0.5g OF STARLIGHT · 2026</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
Object.assign(window, { HomepageB, AccretionDisk, MenuRowB, B_INK, B_INK2, B_TEXT, B_DIM, B_AMBER });
