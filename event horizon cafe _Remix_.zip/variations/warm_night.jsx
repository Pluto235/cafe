// Variation A · 暖夜星河 / Warm Night
// 墨蓝底 + 暖金 + 米白；油画星空质感；最完整的实现
const { useState, useEffect, useMemo, useRef } = React;

const A_PALETTE = {
  ink: '#0d1838',
  ink2: '#162447',
  ink3: '#1f2f55',
  gold: '#e9b86a',
  goldDeep: '#c9954a',
  cream: '#f3e7c7',
  paper: '#fbf3e0',
  rose: '#d68a8a',
};

// === Starfield BG (canvas) ===
function StarfieldA({ density = 1, shooting = 1 }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    let raf, w, h, stars = [], shoots = [];
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    function resize() {
      w = c.clientWidth; h = c.clientHeight;
      c.width = w * dpr; c.height = h * dpr;
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const n = Math.floor(w * h / 1800 * density);
      stars = Array.from({length: n}, () => ({
        x: Math.random()*w, y: Math.random()*h,
        r: Math.random()*1.2 + 0.2,
        a: Math.random()*0.7 + 0.3,
        tw: Math.random()*0.02 + 0.005,
        ph: Math.random()*Math.PI*2,
        warm: Math.random() < 0.35,
      }));
    }
    function spawnShoot() {
      if (Math.random() < 0.003 * shooting) {
        shoots.push({
          x: Math.random()*w*0.7 + w*0.1,
          y: Math.random()*h*0.4,
          vx: 4 + Math.random()*3,
          vy: 1.2 + Math.random()*1,
          life: 0, max: 60 + Math.random()*30,
        });
      }
    }
    function tick(t) {
      ctx.clearRect(0,0,w,h);
      // soft nebula glow
      const g = ctx.createRadialGradient(w*0.7, h*0.3, 0, w*0.7, h*0.3, Math.max(w,h)*0.6);
      g.addColorStop(0, 'rgba(233,184,106,0.10)');
      g.addColorStop(0.4, 'rgba(156,123,214,0.05)');
      g.addColorStop(1, 'rgba(13,24,56,0)');
      ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
      const g2 = ctx.createRadialGradient(w*0.2, h*0.85, 0, w*0.2, h*0.85, Math.max(w,h)*0.5);
      g2.addColorStop(0, 'rgba(108,140,210,0.10)');
      g2.addColorStop(1, 'rgba(13,24,56,0)');
      ctx.fillStyle = g2; ctx.fillRect(0,0,w,h);
      // stars
      for (const s of stars) {
        const a = s.a * (0.6 + 0.4*Math.sin(t*s.tw + s.ph));
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
        ctx.fillStyle = s.warm
          ? `rgba(243, 231, 199, ${a})`
          : `rgba(233, 222, 200, ${a*0.85})`;
        ctx.fill();
        if (s.r > 0.9) {
          ctx.beginPath(); ctx.arc(s.x,s.y,s.r*3,0,Math.PI*2);
          ctx.fillStyle = `rgba(233,184,106,${a*0.08})`; ctx.fill();
        }
      }
      // shooting stars
      spawnShoot();
      shoots = shoots.filter(sh => {
        sh.life++;
        const head = sh.life / sh.max;
        if (head >= 1) return false;
        const len = 80;
        const tx = sh.x + sh.vx * sh.life;
        const ty = sh.y + sh.vy * sh.life;
        const grd = ctx.createLinearGradient(tx, ty, tx-len, ty-len*sh.vy/sh.vx);
        grd.addColorStop(0, `rgba(251,243,224,${0.9*(1-head)})`);
        grd.addColorStop(1, 'rgba(251,243,224,0)');
        ctx.strokeStyle = grd; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(tx,ty);
        ctx.lineTo(tx-len, ty-len*sh.vy/sh.vx); ctx.stroke();
        return true;
      });
      raf = requestAnimationFrame(tick);
    }
    resize();
    const ro = new ResizeObserver(resize); ro.observe(c);
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [density, shooting]);
  return <canvas ref={ref} style={{ position:'absolute', inset:0, width:'100%', height:'100%' }} />;
}

// === Hero: a galaxy-shake (奶昔星系) ===
function GalaxyShakeA() {
  return (
    <div style={{ position:'relative', width: 380, height: 520, margin:'0 auto' }}>
      <style>{`
        @keyframes a-spin { from { transform: rotate(0deg);} to { transform: rotate(360deg);} }
        @keyframes a-spin-rev { from { transform: rotate(0deg);} to { transform: rotate(-360deg);} }
        @keyframes a-float { 0%,100% { transform: translateY(0);} 50% { transform: translateY(-8px);} }
      `}</style>
      {/* outer orbit */}
      <div style={{ position:'absolute', inset:0, animation:'a-spin 60s linear infinite' }}>
        <svg viewBox="-200 -260 400 520" style={{ width:'100%', height:'100%', overflow:'visible' }}>
          <ellipse cx="0" cy="0" rx="180" ry="60" fill="none" stroke="rgba(233,184,106,0.25)" strokeDasharray="2 6" strokeWidth="0.8" />
          <circle cx="180" cy="0" r="3" fill="#e9b86a" />
        </svg>
      </div>
      <div style={{ position:'absolute', inset:0, animation:'a-spin-rev 90s linear infinite' }}>
        <svg viewBox="-200 -260 400 520" style={{ width:'100%', height:'100%', overflow:'visible' }}>
          <ellipse cx="0" cy="0" rx="160" ry="200" fill="none" stroke="rgba(251,243,224,0.18)" strokeWidth="0.6" />
          <circle cx="0" cy="200" r="2" fill="#fbf3e0" />
          <circle cx="113" cy="-141" r="1.4" fill="#fbf3e0" opacity="0.7" />
        </svg>
      </div>
      {/* glass */}
      <div style={{ position:'absolute', left:'50%', top:'50%', transform:'translate(-50%,-50%)', animation:'a-float 6s ease-in-out infinite' }}>
        <svg width="220" height="320" viewBox="0 0 220 320">
          <defs>
            <radialGradient id="a-galaxy" cx="50%" cy="45%" r="55%">
              <stop offset="0%" stopColor="#fbf3e0" />
              <stop offset="20%" stopColor="#e9b86a" />
              <stop offset="55%" stopColor="#9c7bd6" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#0d1838" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="a-glass" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="rgba(251,243,224,0.25)" />
              <stop offset="100%" stopColor="rgba(251,243,224,0.05)" />
            </linearGradient>
            <radialGradient id="a-spiral" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fbf3e0" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#fbf3e0" stopOpacity="0" />
            </radialGradient>
          </defs>
          {/* glass cup */}
          <path d="M 30 60 L 60 280 Q 60 296 76 296 L 144 296 Q 160 296 160 280 L 190 60 Z"
                fill="url(#a-glass)" stroke="rgba(251,243,224,0.5)" strokeWidth="1.2" />
          {/* liquid surface ellipse */}
          <ellipse cx="110" cy="62" rx="80" ry="12" fill="#0d1838" opacity="0.6" />
          {/* galaxy disk inside cup */}
          <g style={{ transformOrigin:'110px 160px', animation:'a-spin 24s linear infinite' }}>
            <ellipse cx="110" cy="160" rx="78" ry="78" fill="url(#a-galaxy)" />
            {/* spiral arms */}
            <path d="M 110 160 Q 150 130 168 168 Q 180 200 130 200 Q 90 195 110 160"
                  fill="url(#a-spiral)" opacity="0.55" />
            <path d="M 110 160 Q 70 190 52 152 Q 40 120 90 120 Q 130 125 110 160"
                  fill="url(#a-spiral)" opacity="0.45" />
            {/* core */}
            <circle cx="110" cy="160" r="14" fill="#fbf3e0" />
            <circle cx="110" cy="160" r="6" fill="#fff" />
          </g>
          {/* straw */}
          <line x1="138" y1="20" x2="120" y2="290" stroke="#e9b86a" strokeWidth="3" strokeLinecap="round" />
          <line x1="138" y1="20" x2="120" y2="290" stroke="#fbf3e0" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
          {/* highlight */}
          <path d="M 50 80 L 70 250" stroke="rgba(251,243,224,0.5)" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
}

// === Spectrum (radar chart) ===
function SpectrumA({ data, color }) {
  const labels = Object.keys(data);
  const values = Object.values(data);
  const n = labels.length;
  const cx = 60, cy = 60, R = 48;
  const pts = values.map((v,i) => {
    const a = -Math.PI/2 + i * 2*Math.PI/n;
    return [cx + Math.cos(a)*R*v, cy + Math.sin(a)*R*v];
  });
  const grid = [0.25, 0.5, 0.75, 1].map(k => labels.map((_,i) => {
    const a = -Math.PI/2 + i * 2*Math.PI/n;
    return [cx + Math.cos(a)*R*k, cy + Math.sin(a)*R*k];
  }));
  return (
    <svg width="160" height="160" viewBox="0 0 120 120" style={{ overflow:'visible' }}>
      {grid.map((ring, i) => (
        <polygon key={i} points={ring.map(p=>p.join(',')).join(' ')}
                 fill="none" stroke="rgba(251,243,224,0.15)" strokeWidth="0.4" />
      ))}
      {labels.map((_,i) => {
        const a = -Math.PI/2 + i * 2*Math.PI/n;
        return <line key={i} x1={cx} y1={cy} x2={cx+Math.cos(a)*R} y2={cy+Math.sin(a)*R}
                     stroke="rgba(251,243,224,0.12)" strokeWidth="0.4" />;
      })}
      <polygon points={pts.map(p=>p.join(',')).join(' ')}
               fill={color} fillOpacity="0.32" stroke={color} strokeWidth="1" />
      {pts.map((p,i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="1.6" fill={color} />
      ))}
      {labels.map((l,i) => {
        const a = -Math.PI/2 + i * 2*Math.PI/n;
        const lx = cx + Math.cos(a)*(R+10);
        const ly = cy + Math.sin(a)*(R+10);
        return <text key={i} x={lx} y={ly} fill="rgba(251,243,224,0.8)" fontSize="6"
                     textAnchor="middle" dominantBaseline="middle"
                     style={{ fontFamily:'"Noto Serif SC", serif' }}>{l}</text>;
      })}
    </svg>
  );
}

function MenuCardA({ item, onAdd }) {
  const [hover, setHover] = useState(false);
  return (
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
         style={{
           position:'relative',
           background: 'linear-gradient(180deg, rgba(22,36,71,0.6), rgba(13,24,56,0.85))',
           border:'1px solid rgba(233,184,106,0.18)',
           borderRadius: 2,
           padding: 28, paddingBottom: 24,
           overflow:'hidden',
           transition:'border-color .3s, transform .3s',
           borderColor: hover ? 'rgba(233,184,106,0.5)' : 'rgba(233,184,106,0.18)',
         }}>
      {/* index number */}
      <div style={{ position:'absolute', top:18, right:22, fontFamily:'"EB Garamond", serif',
                    fontSize: 13, fontStyle:'italic', color:'rgba(233,184,106,0.5)', letterSpacing:'0.1em' }}>
        № {item.id.slice(0,3).toUpperCase()}
      </div>
      <div style={{ display:'flex', alignItems:'baseline', gap: 14, marginBottom: 4 }}>
        <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 17,
                       color: item.accent, letterSpacing:'0.04em' }}>{item.en}</span>
      </div>
      <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 30, color:'#fbf3e0',
                    letterSpacing:'0.05em', marginBottom: 10, fontWeight: 500 }}>{item.cn}</div>
      <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 12, color:'rgba(251,243,224,0.55)',
                    letterSpacing:'0.15em', marginBottom: 14 }}>
        {item.sub}
      </div>
      <div style={{ height: 1, background:'linear-gradient(90deg, rgba(233,184,106,0.4), transparent)',
                    marginBottom: 16 }} />
      <div style={{ position:'relative', height: 160, marginBottom: 14 }}>
        {/* blurb fades out, spectrum fades in */}
        <p style={{
          position:'absolute', inset:0,
          fontFamily:'"Noto Serif SC", serif', fontSize: 13, lineHeight: 1.85,
          color:'rgba(251,243,224,0.78)', margin:0, textWrap:'pretty',
          opacity: hover ? 0 : 1, transition:'opacity .3s',
        }}>
          {item.blurb}
        </p>
        <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center',
                      opacity: hover ? 1 : 0, transition:'opacity .3s' }}>
          <SpectrumA data={item.spectrum} color={item.accent} />
        </div>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
        <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 22, color: item.accent }}>
          ¥ {item.price}
        </div>
        <button onClick={()=>onAdd(item)} style={{
          background: 'transparent', border:'1px solid rgba(233,184,106,0.5)',
          color:'#e9b86a', padding: '8px 18px', cursor:'pointer',
          fontFamily:'"Noto Serif SC", serif', fontSize: 12, letterSpacing:'0.2em',
          borderRadius: 1, transition:'all .2s',
        }}
        onMouseDown={e=>e.currentTarget.style.background='rgba(233,184,106,0.15)'}
        onMouseUp={e=>e.currentTarget.style.background='transparent'}>
          加入 · ADD
        </button>
      </div>
    </div>
  );
}

function HomepageA() {
  const [cart, setCart] = useState([]);
  const [pickup, setPickup] = useState('19:30');
  const [name, setName] = useState('');
  const [note, setNote] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [wishText, setWishText] = useState('');
  const [wishes, setWishes] = useState(window.EHC_WISHES);
  const today = window.EHC_TODAY;

  const total = cart.reduce((s,c)=>s+c.price*c.qty, 0);
  function add(item) {
    setCart(prev => {
      const f = prev.find(x=>x.id===item.id);
      if (f) return prev.map(x=>x.id===item.id?{...x, qty:x.qty+1}:x);
      return [...prev, {...item, qty:1}];
    });
  }
  function dec(id) {
    setCart(prev => prev.map(x=>x.id===id?{...x,qty:x.qty-1}:x).filter(x=>x.qty>0));
  }
  function inc(id) {
    setCart(prev => prev.map(x=>x.id===id?{...x,qty:x.qty+1}:x));
  }
  const times = ['18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00'];

  return (
    <div style={{
      background: A_PALETTE.ink, color: A_PALETTE.cream,
      fontFamily:'"Noto Serif SC", "Songti SC", serif',
      width:'100%', minHeight:'100%',
    }}>
      {/* HERO */}
      <section style={{ position:'relative', height: 1080, overflow:'hidden',
                        background:'radial-gradient(ellipse at 70% 30%, #1f2f55 0%, #0d1838 60%, #060c1f 100%)' }}>
        <StarfieldA density={1.2} shooting={1.2} />
        {/* nav */}
        <nav style={{
          position:'absolute', top:0, left:0, right:0, zIndex: 10,
          display:'flex', alignItems:'center', justifyContent:'space-between',
          padding:'34px 64px',
        }}>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <svg width="34" height="34" viewBox="0 0 40 40">
              <circle cx="20" cy="20" r="6" fill="#0d1838" stroke="#e9b86a" strokeWidth="1" />
              <ellipse cx="20" cy="20" rx="18" ry="6" fill="none" stroke="#e9b86a" strokeWidth="0.8" transform="rotate(-25 20 20)" />
              <circle cx="20" cy="20" r="2" fill="#e9b86a" />
            </svg>
            <div>
              <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 16,
                            color:'#e9b86a', letterSpacing:'0.18em', lineHeight: 1 }}>
                event horizon
              </div>
              <div style={{ fontSize: 10, color:'rgba(251,243,224,0.55)', letterSpacing:'0.4em', marginTop:4 }}>
                CAFÉ · 视界 咖啡馆
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap: 38, fontSize: 13, letterSpacing:'0.25em' }}>
            {[['本月菜单','MENU'],['预约点单','ORDER'],['星愿墙','WISHES'],['关于','ABOUT']].map(([cn,en])=>(
              <a key={en} href={`#${en.toLowerCase()}`} style={{ color:'rgba(251,243,224,0.85)', textDecoration:'none', display:'flex', flexDirection:'column', gap:2 }}>
                <span>{cn}</span>
                <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 10,
                               color:'rgba(233,184,106,0.6)', letterSpacing:'0.2em' }}>{en}</span>
              </a>
            ))}
          </div>
        </nav>

        {/* hero content */}
        <div style={{ position:'absolute', inset:0, display:'grid',
                      gridTemplateColumns:'1fr 1fr', alignItems:'center', padding:'0 80px', gap: 40, zIndex: 5 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 18,
                          color:'#e9b86a', letterSpacing:'0.3em', marginBottom: 24 }}>
              — A milkshake of one's own galaxy —
            </div>
            <h1 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 86,
                         lineHeight: 1.15, margin: 0, letterSpacing:'0.04em', color:'#fbf3e0' }}>
              在 <span style={{ color:'#e9b86a', fontStyle:'italic', fontFamily:'"EB Garamond", serif' }}>视界</span> 之内，<br/>
              我们摇<br/>一杯星系给你。
            </h1>
            <p style={{ marginTop: 36, fontSize: 16, lineHeight: 2, color:'rgba(251,243,224,0.78)',
                        maxWidth: 460, textWrap:'pretty' }}>
              我们是天文系的几个学生，把奶昔做成了星图。每一杯都对应一个真实的天体，
              从英仙座流星雨到天鹅座 X-1 的黑洞回响 —— 喝下去之前，先读一段它的简介。
            </p>
            <div style={{ marginTop: 44, display:'flex', gap: 16 }}>
              <a href="#menu" style={{
                padding:'18px 36px', background:'#e9b86a', color:'#0d1838',
                fontSize: 13, letterSpacing:'0.3em', textDecoration:'none',
                fontFamily:'"Noto Serif SC", serif', fontWeight: 500,
              }}>查看本月菜单 · MENU</a>
              <a href="#order" style={{
                padding:'18px 36px', border:'1px solid rgba(251,243,224,0.4)', color:'#fbf3e0',
                fontSize: 13, letterSpacing:'0.3em', textDecoration:'none',
                fontFamily:'"Noto Serif SC", serif',
              }}>在线预约 · ORDER</a>
            </div>
          </div>
          <div style={{ display:'flex', justifyContent:'center', alignItems:'center' }}>
            <GalaxyShakeA />
          </div>
        </div>

        {/* ticker */}
        <div style={{ position:'absolute', bottom: 32, left: 64, right: 64, zIndex: 6,
                      display:'flex', justifyContent:'space-between', alignItems:'center',
                      borderTop:'1px solid rgba(233,184,106,0.25)', paddingTop: 22 }}>
          <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.55)' }}>
            {today.dateEn.toUpperCase()} · {today.date}
          </div>
          <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 14, color:'#e9b86a' }}>
            ✦ {today.highlight}
          </div>
          <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.55)' }}>
            HOURS · {today.hours}
          </div>
        </div>
      </section>

      {/* TODAY'S SKY */}
      <section style={{ padding: '120px 80px', background:'#0a1330', position:'relative' }}>
        <div style={{ display:'grid', gridTemplateColumns:'auto 1fr', gap: 80, alignItems:'center' }}>
          <div style={{ borderLeft:'1px solid rgba(233,184,106,0.5)', paddingLeft: 32 }}>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 12,
                          color:'rgba(233,184,106,0.7)', letterSpacing:'0.3em' }}>
              TONIGHT
            </div>
            <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 42, color:'#fbf3e0',
                          letterSpacing:'0.05em', marginTop: 12 }}>
              今夜天象
            </div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap: 0,
                        borderTop:'1px solid rgba(233,184,106,0.2)',
                        borderBottom:'1px solid rgba(233,184,106,0.2)', padding:'40px 0' }}>
            {[
              ['日落','SUNSET', today.sunset, '#e9b86a'],
              ['月相','MOON', today.moon, '#fbf3e0'],
              ['亮点','HIGHLIGHT', '土星 ⇢ 月球', '#9c7bd6'],
              ['营业','OPEN', today.hours, '#f3e7c7'],
            ].map(([cn,en,val,col], i) => (
              <div key={i} style={{ borderLeft: i? '1px solid rgba(233,184,106,0.15)':'none', paddingLeft: i? 32:0, paddingRight: 32 }}>
                <div style={{ fontSize: 10, letterSpacing:'0.3em', color:'rgba(251,243,224,0.45)' }}>
                  {cn} / {en}
                </div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 28,
                              color: col, marginTop: 12, letterSpacing:'0.04em' }}>
                  {val}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ marginTop: 28, fontSize: 13, color:'rgba(251,243,224,0.6)', textAlign:'center',
                      fontStyle:'italic', fontFamily:'"EB Garamond", serif' }}>
          {today.highlightEn} · 落地窗朝南，建议 21:15 入座
        </div>
      </section>

      {/* MENU */}
      <section id="menu" style={{ padding: '140px 80px', background: A_PALETTE.ink, position:'relative' }}>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 80 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 13,
                          color:'#e9b86a', letterSpacing:'0.4em' }}>
              MENU · MAY 2026
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 64,
                         color:'#fbf3e0', margin:'16px 0 0', letterSpacing:'0.05em' }}>
              本月奶昔 · 六杯星图
            </h2>
          </div>
          <div style={{ maxWidth: 360, fontSize: 13, lineHeight: 1.9, color:'rgba(251,243,224,0.6)',
                        textWrap:'pretty', textAlign:'right' }}>
            悬停每张卡片，会显示这杯奶昔的「光谱」——<br/>
            它的风味在五个维度上的分布。<br/>
            <span style={{ fontStyle:'italic', fontFamily:'"EB Garamond", serif' }}>
              Hover for the spectrum.
            </span>
          </div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap: 24 }}>
          {window.EHC_MENU.map(it => <MenuCardA key={it.id} item={it} onAdd={add} />)}
        </div>
      </section>

      {/* ORDER */}
      <section id="order" style={{ padding: '140px 80px', background:'#0a1330',
                                    backgroundImage:'radial-gradient(circle at 80% 20%, rgba(233,184,106,0.08), transparent 50%)' }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 64 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 13,
                          color:'#e9b86a', letterSpacing:'0.4em' }}>
              RESERVE · ORDER AHEAD
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 56,
                         color:'#fbf3e0', margin:'16px 0 24px', letterSpacing:'0.05em' }}>
              在线预约 / 留一杯星光
            </h2>
            <p style={{ fontSize: 15, lineHeight: 2, color:'rgba(251,243,224,0.7)',
                        maxWidth: 460, textWrap:'pretty' }}>
              选好奶昔，挑一个取餐时间，我们会按时把它端到你最喜欢的窗边。
              不用付定金，到店再结账；如果当晚有特别的天象，我们会在备注里告诉你最佳观测窗口。
            </p>
            <div style={{ marginTop: 48 }}>
              <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.5)', marginBottom: 16 }}>
                取餐时间 · PICKUP TIME
              </div>
              <div style={{ display:'flex', flexWrap:'wrap', gap: 8 }}>
                {times.map(t => (
                  <button key={t} onClick={()=>setPickup(t)} style={{
                    padding:'12px 18px', background: pickup===t ? '#e9b86a' : 'transparent',
                    color: pickup===t ? '#0d1838' : '#fbf3e0',
                    border:'1px solid rgba(233,184,106,0.4)',
                    fontFamily:'"EB Garamond", serif', fontSize: 16, fontStyle:'italic',
                    cursor:'pointer', transition:'all .15s', letterSpacing:'0.05em',
                  }}>{t}</button>
                ))}
              </div>
            </div>
            <div style={{ marginTop: 36, display:'grid', gap: 16 }}>
              <input value={name} onChange={e=>setName(e.target.value)} placeholder="姓名 / Name"
                     style={{
                       background:'transparent', border:'none',
                       borderBottom:'1px solid rgba(233,184,106,0.4)',
                       padding:'14px 4px', fontSize: 16, color:'#fbf3e0',
                       fontFamily:'"Noto Serif SC", serif', outline:'none',
                     }} />
              <input value={note} onChange={e=>setNote(e.target.value)} placeholder="备注 · 留座/外带/特别要求 — leave a note"
                     style={{
                       background:'transparent', border:'none',
                       borderBottom:'1px solid rgba(233,184,106,0.4)',
                       padding:'14px 4px', fontSize: 16, color:'#fbf3e0',
                       fontFamily:'"Noto Serif SC", serif', outline:'none',
                     }} />
            </div>
          </div>
          {/* cart */}
          <div style={{ background:'rgba(13,24,56,0.6)', border:'1px solid rgba(233,184,106,0.2)',
                         padding: 40, position:'relative' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline',
                          borderBottom:'1px solid rgba(233,184,106,0.2)', paddingBottom: 18, marginBottom: 24 }}>
              <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 22, color:'#fbf3e0' }}>
                购物车 / Cart
              </div>
              <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(233,184,106,0.7)',
                            fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>
                {cart.length} ITEMS
              </div>
            </div>
            {cart.length === 0 ? (
              <div style={{ padding:'40px 0', textAlign:'center', color:'rgba(251,243,224,0.4)',
                            fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 16 }}>
                — empty event horizon —<br/>
                <span style={{ fontFamily:'"Noto Serif SC", serif', fontStyle:'normal', fontSize: 13 }}>
                  从上方的菜单加入一杯
                </span>
              </div>
            ) : (
              <div style={{ display:'grid', gap: 16 }}>
                {cart.map(c => (
                  <div key={c.id} style={{ display:'grid', gridTemplateColumns:'1fr auto auto',
                                            alignItems:'center', gap: 16, padding:'12px 0',
                                            borderBottom:'1px dashed rgba(233,184,106,0.15)' }}>
                    <div>
                      <div style={{ fontSize: 17, color:'#fbf3e0' }}>{c.cn}</div>
                      <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                    fontSize: 12, color: c.accent }}>{c.en}</div>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap: 10,
                                   border:'1px solid rgba(233,184,106,0.3)', padding:'4px 10px' }}>
                      <button onClick={()=>dec(c.id)} style={{ background:'none', border:'none', color:'#e9b86a', cursor:'pointer', fontSize: 14 }}>−</button>
                      <span style={{ fontSize: 14, color:'#fbf3e0', minWidth: 14, textAlign:'center' }}>{c.qty}</span>
                      <button onClick={()=>inc(c.id)} style={{ background:'none', border:'none', color:'#e9b86a', cursor:'pointer', fontSize: 14 }}>+</button>
                    </div>
                    <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 17,
                                   color:'#e9b86a', minWidth: 60, textAlign:'right' }}>
                      ¥{c.price*c.qty}
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div style={{ marginTop: 32, display:'grid', gridTemplateColumns:'1fr auto', gap: 16,
                          alignItems:'center' }}>
              <div>
                <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.5)' }}>
                  取餐 PICKUP
                </div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 22,
                              color:'#fbf3e0', marginTop: 4 }}>
                  Tonight · {pickup}
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.5)' }}>
                  合计 TOTAL
                </div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 32,
                              color:'#e9b86a', marginTop: 4 }}>
                  ¥ {total}
                </div>
              </div>
            </div>
            <button onClick={()=>{ if(cart.length) setSubmitted(true); }}
                    disabled={!cart.length}
                    style={{
                      marginTop: 24, width:'100%', padding:'18px',
                      background: cart.length? '#e9b86a':'rgba(233,184,106,0.2)',
                      color: cart.length? '#0d1838':'rgba(251,243,224,0.4)',
                      border:'none', cursor: cart.length?'pointer':'not-allowed',
                      fontFamily:'"Noto Serif SC", serif', fontSize: 14, letterSpacing:'0.4em',
                      fontWeight: 500,
                    }}>
              {submitted ? '已预约 · RESERVED ✦' : '确认预约 · CONFIRM ORDER'}
            </button>
            {submitted && (
              <div style={{ marginTop: 14, fontSize: 13, color:'#e9b86a', textAlign:'center',
                            fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>
                We'll have your galaxy ready at {pickup}.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* WISHES */}
      <section id="wishes" style={{ padding: '140px 80px', background: A_PALETTE.ink, position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, opacity: 0.4 }}>
          <StarfieldA density={0.5} shooting={0.3} />
        </div>
        <div style={{ position:'relative', zIndex: 1, display:'grid', gridTemplateColumns:'1fr 1fr', gap: 80 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 13,
                          color:'#e9b86a', letterSpacing:'0.4em' }}>
              ✦ WALL OF WISHES
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 56,
                         color:'#fbf3e0', margin:'16px 0 32px', letterSpacing:'0.05em' }}>
              星愿墙
            </h2>
            <p style={{ fontSize: 15, lineHeight: 2, color:'rgba(251,243,224,0.7)',
                        maxWidth: 420, textWrap:'pretty' }}>
              在这里写下你想发给宇宙的一句话。无论是 deadline 前的祈祷、
              还是某个偷偷喜欢的人的名字，我们会把它打印出来贴在吧台上方，
              直到下一个新月。
            </p>
            <div style={{ marginTop: 36 }}>
              <textarea value={wishText} onChange={e=>setWishText(e.target.value)}
                        placeholder="把你的星愿写在这里… / Send a photon into the dark."
                        rows={4} style={{
                          width:'100%', background:'rgba(13,24,56,0.6)',
                          border:'1px solid rgba(233,184,106,0.3)',
                          padding: 20, color:'#fbf3e0',
                          fontFamily:'"Noto Serif SC", serif', fontSize: 15,
                          lineHeight: 1.8, resize:'none', outline:'none',
                          boxSizing:'border-box',
                        }} />
              <button onClick={()=>{
                if (!wishText.trim()) return;
                setWishes(w=>[{ name: name||'匿名 Anonymous', text: wishText, when:'刚刚' }, ...w]);
                setWishText('');
              }} style={{
                marginTop: 16, padding:'14px 32px', background:'transparent',
                color:'#e9b86a', border:'1px solid #e9b86a',
                fontFamily:'"Noto Serif SC", serif', fontSize: 13, letterSpacing:'0.3em',
                cursor:'pointer',
              }}>
                ✦ 寄出 · SEND
              </button>
            </div>
          </div>
          <div style={{ display:'grid', gap: 14, maxHeight: 540, overflow:'hidden',
                        WebkitMaskImage:'linear-gradient(180deg, transparent 0%, #000 12%, #000 88%, transparent 100%)',
                        maskImage:'linear-gradient(180deg, transparent 0%, #000 12%, #000 88%, transparent 100%)' }}>
            {wishes.map((w,i) => (
              <div key={i} style={{
                background: 'rgba(22,36,71,0.5)',
                border:'1px solid rgba(233,184,106,0.15)',
                padding: 22,
                transform: `rotate(${(i%3-1)*0.5}deg)`,
              }}>
                <p style={{ margin:0, fontSize: 14, lineHeight: 1.85, color:'rgba(251,243,224,0.88)',
                            fontFamily:'"Noto Serif SC", serif', textWrap:'pretty' }}>
                  「{w.text}」
                </p>
                <div style={{ marginTop: 12, display:'flex', justifyContent:'space-between',
                              fontSize: 11, letterSpacing:'0.2em', color:'rgba(233,184,106,0.55)',
                              fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>
                  <span>— {w.name}</span>
                  <span>{w.when}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: '60px 80px 40px', background:'#060c1f',
                       borderTop:'1px solid rgba(233,184,106,0.2)' }}>
        <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr 1fr 1fr', gap: 40 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 22,
                          color:'#e9b86a', letterSpacing:'0.15em' }}>event horizon café</div>
            <div style={{ marginTop: 14, fontSize: 13, lineHeight: 1.9, color:'rgba(251,243,224,0.55)' }}>
              天文系学生小店<br/>
              <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>
                A small shop run by astronomy undergrads.
              </span>
            </div>
          </div>
          {[
            ['LOCATION · 位置', ['天文系楼 1F · 西侧庭院', 'Astronomy Bldg, 1F West']],
            ['HOURS · 时间', ['周二–周日 · 14:00–23:30','Tue–Sun, until pitch night']],
            ['SOCIAL · 联系', ['@event.horizon.cafe','wechat: ehc_observatory']],
          ].map(([t,lines],i) => (
            <div key={i}>
              <div style={{ fontSize: 10, letterSpacing:'0.4em', color:'rgba(233,184,106,0.6)',
                            fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>{t}</div>
              <div style={{ marginTop: 12, fontSize: 13, lineHeight: 1.9, color:'rgba(251,243,224,0.65)' }}>
                {lines.map((l,j)=><div key={j}>{l}</div>)}
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 60, paddingTop: 24, borderTop:'1px solid rgba(233,184,106,0.1)',
                       display:'flex', justifyContent:'space-between',
                       fontSize: 11, letterSpacing:'0.3em', color:'rgba(251,243,224,0.4)',
                       fontFamily:'"EB Garamond", serif', fontStyle:'italic' }}>
          <span>© 2026 EVENT HORIZON CAFÉ</span>
          <span>made with photons & 0.5 grams of starlight</span>
        </div>
      </footer>
    </div>
  );
}

Object.assign(window, { HomepageA, GalaxyShakeA, StarfieldA });
