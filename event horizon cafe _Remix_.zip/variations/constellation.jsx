// Variation C · 星座连线 / Constellation
// 米白底 + 深墨蓝绘图 + 暖金点缀；轻盈优雅，像天文图录
const { useState: useStateC, useRef: useRefC, useEffect: useEffectC } = React;

const C_PAPER = '#f3ecdc';
const C_PAPER2 = '#e9e0c8';
const C_INK = '#1a2540';
const C_INK2 = '#2d3a5c';
const C_GOLD = '#b8893f';
const C_ROSE = '#a85a5a';

// constellation hero — connected dots, hover-lit
function ConstellationHero() {
  const stars = [
    {x:80, y:200}, {x:160, y:120}, {x:240, y:180}, {x:330, y:90},
    {x:420, y:160}, {x:500, y:240}, {x:380, y:280}, {x:280, y:340},
    {x:180, y:300}, {x:90, y:360},
  ];
  const lines = [[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[8,9],[8,2],[6,4]];
  return (
    <div style={{ position:'relative', width:'100%', height: 460 }}>
      <style>{`
        @keyframes c-twinkle { 0%,100%{opacity:0.5} 50%{opacity:1} }
      `}</style>
      <svg viewBox="0 0 600 460" style={{ width:'100%', height:'100%' }}>
        <defs>
          <radialGradient id="c-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={C_GOLD} stopOpacity="0.5" />
            <stop offset="100%" stopColor={C_GOLD} stopOpacity="0" />
          </radialGradient>
        </defs>
        {/* connection lines */}
        {lines.map(([a,b],i) => (
          <line key={i} x1={stars[a].x} y1={stars[a].y} x2={stars[b].x} y2={stars[b].y}
                stroke={C_INK} strokeWidth="0.6" opacity="0.4" strokeDasharray="2 4" />
        ))}
        {/* stars */}
        {stars.map((s,i) => (
          <g key={i}>
            <circle cx={s.x} cy={s.y} r="14" fill="url(#c-glow)" />
            <circle cx={s.x} cy={s.y} r={i%3===0?4:2.5} fill={C_INK}
                    style={{ animation:`c-twinkle ${3+i*0.3}s ease-in-out infinite`, animationDelay:`${i*0.2}s` }} />
          </g>
        ))}
        {/* milkshake glass at center */}
        <g transform="translate(260, 130)" opacity="0.94">
          <path d="M 20 30 L 30 130 Q 30 140 40 140 L 70 140 Q 80 140 80 130 L 90 30 Z"
                fill={C_PAPER} stroke={C_INK} strokeWidth="1.2" />
          <ellipse cx="55" cy="32" rx="35" ry="6" fill={C_INK} />
          <ellipse cx="55" cy="32" rx="32" ry="4.5" fill={C_GOLD} opacity="0.6" />
          <line x1="68" y1="14" x2="60" y2="135" stroke={C_GOLD} strokeWidth="2" strokeLinecap="round" />
          {/* swirl */}
          <path d="M 38 90 Q 55 75 72 90 Q 65 105 50 95" fill="none" stroke={C_INK} strokeWidth="0.6" />
          <circle cx="55" cy="92" r="2" fill={C_GOLD} />
        </g>
        {/* labels */}
        <text x="86" y="220" fill={C_INK} fontSize="9" fontFamily="EB Garamond" fontStyle="italic" opacity="0.5">α</text>
        <text x="246" y="200" fill={C_INK} fontSize="9" fontFamily="EB Garamond" fontStyle="italic" opacity="0.5">β</text>
        <text x="426" y="180" fill={C_INK} fontSize="9" fontFamily="EB Garamond" fontStyle="italic" opacity="0.5">γ</text>
        <text x="306" y="365" fill={C_INK} fontSize="9" fontFamily="EB Garamond" fontStyle="italic" opacity="0.5">δ</text>
      </svg>
      <div style={{ position:'absolute', top: 12, right: 12,
                     fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                     fontSize: 12, color: C_INK2, letterSpacing:'0.15em', textAlign:'right' }}>
        FIG. 03 — A LIGHT CONSTELLATION<br/>FOR THE DRINKER'S SKY
      </div>
    </div>
  );
}

function MenuTileC({ item, onAdd }) {
  const [hover, setHover] = useStateC(false);
  return (
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
         style={{
           background: C_PAPER, padding: 28,
           border:`0.6px solid ${C_INK}`,
           position:'relative', transition:'transform .35s, box-shadow .35s',
           transform: hover? 'translateY(-4px)':'none',
           boxShadow: hover? `4px 4px 0 ${C_INK}` : `2px 2px 0 ${C_INK2}`,
         }}>
      {/* tiny constellation icon */}
      <svg width="100%" height="120" viewBox="0 0 200 120" style={{ marginBottom: 14 }}>
        {(() => {
          // pseudo-deterministic stars from id
          const seed = item.id.charCodeAt(0) + item.id.charCodeAt(1);
          const pts = Array.from({length: 6}, (_,i) => ({
            x: 20 + ((seed*7 + i*53) % 160),
            y: 15 + ((seed*11 + i*37) % 90),
          }));
          return (
            <>
              {pts.map((p,i) => i>0 && (
                <line key={`l${i}`} x1={pts[i-1].x} y1={pts[i-1].y} x2={p.x} y2={p.y}
                      stroke={C_INK} strokeWidth="0.5" opacity={hover?0.7:0.3} strokeDasharray="2 3" />
              ))}
              {pts.map((p,i) => (
                <circle key={i} cx={p.x} cy={p.y} r={i===2?3.5:2} fill={item.accent}
                        stroke={C_INK} strokeWidth="0.5" />
              ))}
            </>
          );
        })()}
      </svg>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 14,
                       color: C_GOLD, letterSpacing:'0.1em' }}>
          {item.en}
        </div>
        <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 11,
                       color: C_INK2, letterSpacing:'0.2em' }}>
          № {String(item.cn).slice(0,1)}
        </div>
      </div>
      <div style={{ fontFamily:'"Noto Serif SC", serif', fontSize: 26, color: C_INK,
                     marginTop: 6, letterSpacing:'0.04em' }}>{item.cn}</div>
      <div style={{ fontSize: 12, color: C_INK2, marginTop: 8, letterSpacing:'0.1em',
                     fontFamily:'"Noto Serif SC", serif' }}>{item.sub}</div>
      <p style={{ marginTop: 14, fontSize: 13, lineHeight: 1.85, color: C_INK2,
                   textWrap:'pretty', minHeight: 80 }}>
        {item.blurb}
      </p>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                     marginTop: 14, paddingTop: 14, borderTop:`0.6px dashed ${C_INK2}` }}>
        <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                        fontSize: 22, color: C_INK }}>¥{item.price}</span>
        <button onClick={()=>onAdd(item)} style={{
          background: C_INK, color: C_PAPER,
          border:'none', padding:'10px 18px', cursor:'pointer',
          fontFamily:'"Noto Serif SC", serif', fontSize: 12, letterSpacing:'0.25em',
        }}>加入 ✦ ADD</button>
      </div>
    </div>
  );
}

function HomepageC() {
  const [cart, setCart] = useStateC([]);
  const [pickup, setPickup] = useStateC('19:30');
  const [submitted, setSubmitted] = useStateC(false);
  const [wishText, setWishText] = useStateC('');
  const [wishes, setWishes] = useStateC(window.EHC_WISHES);
  const today = window.EHC_TODAY;
  const total = cart.reduce((s,c)=>s+c.price*c.qty,0);
  const add = (it) => setCart(p => {
    const f = p.find(x=>x.id===it.id);
    return f ? p.map(x=>x.id===it.id?{...x,qty:x.qty+1}:x) : [...p, {...it, qty:1}];
  });

  return (
    <div style={{ background: C_PAPER, color: C_INK, fontFamily:'"Noto Serif SC", serif',
                  width:'100%', minHeight:'100%' }}>
      {/* HERO */}
      <section style={{ position:'relative', minHeight: 980, padding:'40px 80px 80px' }}>
        {/* nav */}
        <nav style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                       paddingBottom: 30, borderBottom:`1px solid ${C_INK}` }}>
          <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
            <svg width="32" height="32" viewBox="0 0 32 32">
              <circle cx="16" cy="16" r="14" fill="none" stroke={C_INK} strokeWidth="0.8" />
              <circle cx="16" cy="16" r="3" fill={C_GOLD} />
              <line x1="16" y1="2" x2="16" y2="30" stroke={C_INK} strokeWidth="0.4" strokeDasharray="1 2" />
              <line x1="2" y1="16" x2="30" y2="16" stroke={C_INK} strokeWidth="0.4" strokeDasharray="1 2" />
            </svg>
            <div>
              <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                             fontSize: 17, letterSpacing:'0.1em', color: C_INK }}>
                event horizon café
              </div>
              <div style={{ fontSize: 9, letterSpacing:'0.4em', color: C_INK2, marginTop: 2 }}>
                视界 · 一家小奶昔铺
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap: 32, fontFamily:'"EB Garamond", serif',
                         fontStyle:'italic', fontSize: 14, letterSpacing:'0.1em' }}>
            {[['菜单','Menu'],['预约','Order'],['星愿','Wishes'],['关于','About']].map(([cn,en])=>(
              <a key={en} href={`#${en.toLowerCase()}`}
                 style={{ color: C_INK, textDecoration:'none' }}>
                <span>{cn}</span>
                <span style={{ marginLeft: 6, color: C_GOLD }}>{en}</span>
              </a>
            ))}
          </div>
        </nav>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1.1fr', gap: 60, marginTop: 80, alignItems:'center' }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 16,
                          color: C_GOLD, letterSpacing:'0.2em' }}>
              — Vol. 03 · A field guide to milkshakes —
            </div>
            <h1 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 80,
                         lineHeight: 1.18, margin:'24px 0 0', letterSpacing:'0.04em' }}>
              我们 <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: C_GOLD }}>连</span> 起<br/>
              你 <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: C_ROSE }}>夜空</span><br/>
              里 的 星 与 杯。
            </h1>
            <p style={{ marginTop: 32, fontSize: 16, lineHeight: 2.1, color: C_INK2,
                         maxWidth: 480, textWrap:'pretty' }}>
              以六颗 / 六杯为本月星图。每一杯背后都是一段天文学小注，
              你可以照着喝、照着想、或照着发呆。
            </p>
            <p style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 16,
                         lineHeight: 1.8, color: C_INK2, maxWidth: 480, marginTop: 18 }}>
              "Connect the stars in your sky, and tell us which one tastes best."
            </p>
            <div style={{ marginTop: 44, display:'flex', gap: 14, alignItems:'center' }}>
              <a href="#menu" style={{
                padding:'16px 32px', background: C_INK, color: C_PAPER,
                fontSize: 13, letterSpacing:'0.3em', textDecoration:'none',
                fontFamily:'"Noto Serif SC", serif',
              }}>查看本月菜单</a>
              <a href="#order" style={{
                padding:'16px 32px', background:'transparent', color: C_INK,
                border:`1px solid ${C_INK}`, fontSize: 13, letterSpacing:'0.3em',
                textDecoration:'none', fontFamily:'"Noto Serif SC", serif',
              }}>在线预约 →</a>
            </div>
          </div>
          <ConstellationHero />
        </div>

        {/* tonight ribbon */}
        <div style={{ marginTop: 80, padding:'24px 32px',
                       border:`1px solid ${C_INK}`, background: C_PAPER2,
                       display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div style={{ display:'flex', alignItems:'center', gap: 16 }}>
            <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                            fontSize: 22, color: C_GOLD }}>✦</span>
            <div>
              <div style={{ fontSize: 10, letterSpacing:'0.3em', color: C_INK2 }}>TONIGHT · {today.dateEn.toUpperCase()}</div>
              <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                             fontSize: 22, color: C_INK, marginTop: 4 }}>
                {today.highlight}
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap: 40 }}>
            {[['日落',today.sunset],['月相','蛾眉月'],['营业',today.hours]].map(([k,v],i) => (
              <div key={i}>
                <div style={{ fontSize: 10, letterSpacing:'0.3em', color: C_INK2 }}>{k}</div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                fontSize: 18, color: C_INK, marginTop: 4 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MENU */}
      <section id="menu" style={{ padding:'120px 80px', background: C_PAPER2, borderTop:`1px solid ${C_INK}` }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom: 56 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                            fontSize: 13, color: C_GOLD, letterSpacing:'0.4em' }}>
              CHAPTER ONE — MAY 2026
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 56,
                          margin:'14px 0 0', letterSpacing:'0.05em' }}>
              本月奶昔 · 六颗星
            </h2>
          </div>
          <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 14,
                         color: C_INK2, maxWidth: 320, textAlign:'right' }}>
            Each card carries a small constellation,<br/>
            drawn for the milkshake it names.
          </div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 24 }}>
          {window.EHC_MENU.map(it => <MenuTileC key={it.id} item={it} onAdd={add} />)}
        </div>
      </section>

      {/* ORDER */}
      <section id="order" style={{ padding:'120px 80px', background: C_PAPER }}>
        <div style={{ display:'grid', gridTemplateColumns:'1.1fr 1fr', gap: 64 }}>
          <div>
            <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                            fontSize: 13, color: C_GOLD, letterSpacing:'0.4em' }}>
              CHAPTER TWO — RESERVE
            </div>
            <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 52,
                          margin:'14px 0 24px' }}>
              留一杯 / Hold a star
            </h2>
            <p style={{ fontSize: 15, lineHeight: 2, color: C_INK2, maxWidth: 460, textWrap:'pretty' }}>
              选品 → 选时间 → 加入购物车，到店扫码即可。
              我们会在你到来之前 5 分钟开始摇杯，让奶香恰好在你坐下时升起。
            </p>
            <div style={{ marginTop: 40 }}>
              <div style={{ fontSize: 11, letterSpacing:'0.3em', color: C_INK2, marginBottom: 14 }}>
                取餐时间 · PICKUP
              </div>
              <div style={{ display:'flex', flexWrap:'wrap', gap: 0, border:`1px solid ${C_INK}` }}>
                {['18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00'].map((t,i) => (
                  <button key={t} onClick={()=>setPickup(t)} style={{
                    flex:'1 0 25%',
                    padding: '14px 0', background: pickup===t? C_INK : 'transparent',
                    color: pickup===t? C_PAPER : C_INK,
                    border:'none',
                    borderRight: (i+1)%4? `1px solid ${C_INK}`:'none',
                    borderTop: i>=4? `1px solid ${C_INK}`:'none',
                    fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                    fontSize: 16, cursor:'pointer',
                  }}>{t}</button>
                ))}
              </div>
            </div>
          </div>
          {/* receipt-style cart */}
          <div style={{ background: C_PAPER, border:`1px solid ${C_INK}`,
                          padding: 36, position:'relative',
                          boxShadow: `4px 4px 0 ${C_INK2}` }}>
            <div style={{ textAlign:'center', borderBottom:`0.6px dashed ${C_INK2}`, paddingBottom: 14, marginBottom: 14 }}>
              <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                              fontSize: 18, color: C_INK, letterSpacing:'0.15em' }}>
                — Order Receipt —
              </div>
              <div style={{ fontSize: 10, letterSpacing:'0.3em', color: C_INK2, marginTop: 4 }}>
                EVENT HORIZON CAFÉ · {today.dateEn.toUpperCase()}
              </div>
            </div>
            {cart.length === 0 ? (
              <div style={{ padding:'30px 0', textAlign:'center', color: C_INK2,
                             fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 15 }}>
                — your cart is a quiet sky —<br/>
                <span style={{ fontFamily:'"Noto Serif SC", serif', fontStyle:'normal',
                                fontSize: 13 }}>从上方加入一杯</span>
              </div>
            ) : (
              cart.map(c => (
                <div key={c.id} style={{ display:'grid', gridTemplateColumns:'1fr auto auto',
                                            gap: 14, padding:'8px 0', alignItems:'baseline',
                                            borderBottom:`0.4px dotted ${C_INK2}` }}>
                  <div style={{ fontSize: 15 }}>{c.cn}
                    <span style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                     fontSize: 12, color: C_GOLD, marginLeft: 8 }}>· {c.en}</span>
                  </div>
                  <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: C_INK2 }}>×{c.qty}</div>
                  <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', color: C_INK,
                                  minWidth: 50, textAlign:'right' }}>¥{c.price*c.qty}</div>
                </div>
              ))
            )}
            <div style={{ marginTop: 18, paddingTop: 12, borderTop:`1px solid ${C_INK}`,
                            display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
              <div>
                <div style={{ fontSize: 10, letterSpacing:'0.3em', color: C_INK2 }}>PICKUP</div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                fontSize: 20, color: C_INK }}>Tonight · {pickup}</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize: 10, letterSpacing:'0.3em', color: C_INK2 }}>TOTAL</div>
                <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                                fontSize: 30, color: C_INK }}>¥{total}</div>
              </div>
            </div>
            <button onClick={()=>cart.length && setSubmitted(true)} disabled={!cart.length} style={{
              marginTop: 20, width:'100%', padding: 14,
              background: cart.length? C_INK : C_PAPER2,
              color: cart.length? C_PAPER: C_INK2,
              border:'none', fontFamily:'"Noto Serif SC", serif',
              fontSize: 13, letterSpacing:'0.4em',
              cursor: cart.length?'pointer':'not-allowed',
            }}>{submitted? `已预约 · See you at ${pickup}` : '确认预约 · CONFIRM'}</button>
          </div>
        </div>
      </section>

      {/* WISHES */}
      <section id="wishes" style={{ padding:'120px 80px', background: C_PAPER2, borderTop:`1px solid ${C_INK}` }}>
        <div style={{ textAlign:'center', marginBottom: 56 }}>
          <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                            fontSize: 13, color: C_GOLD, letterSpacing:'0.4em' }}>
            CHAPTER THREE — WALL OF WISHES
          </div>
          <h2 style={{ fontFamily:'"Noto Serif SC", serif', fontWeight: 400, fontSize: 52,
                        margin:'14px 0 0', letterSpacing:'0.05em' }}>
            星愿墙
          </h2>
          <p style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic', fontSize: 16,
                       color: C_INK2, marginTop: 14 }}>
            Send a tiny photon into the dark, and we'll pin it above the bar.
          </p>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap: 16, marginBottom: 36 }}>
          {wishes.slice(0,6).map((w,i) => (
            <div key={i} style={{
              background: C_PAPER, border:`0.6px solid ${C_INK}`,
              padding: 22, position:'relative',
              transform:`rotate(${(i%3-1)*0.4}deg)`,
            }}>
              {/* tape */}
              <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%) rotate(-2deg)',
                              width: 60, height: 16, background:'rgba(184,137,63,0.35)',
                              borderTop:'0.4px solid rgba(184,137,63,0.5)',
                              borderBottom:'0.4px solid rgba(184,137,63,0.5)' }} />
              <p style={{ margin:'12px 0 0', fontSize: 14, lineHeight: 1.85, color: C_INK,
                            textWrap:'pretty', fontFamily:'"Noto Serif SC", serif' }}>
                「{w.text}」
              </p>
              <div style={{ marginTop: 14, display:'flex', justifyContent:'space-between',
                              fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                              fontSize: 12, color: C_INK2 }}>
                <span>— {w.name}</span>
                <span>{w.when}</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ maxWidth: 720, margin:'0 auto', display:'flex', gap: 12 }}>
          <input value={wishText} onChange={e=>setWishText(e.target.value)}
                  placeholder="把你的星愿写在这里…"
                  style={{ flex:1, padding:'14px 18px', background: C_PAPER,
                           border:`1px solid ${C_INK}`, fontFamily:'"Noto Serif SC", serif',
                           fontSize: 14, color: C_INK, outline:'none' }} />
          <button onClick={()=>{
            if (!wishText.trim()) return;
            setWishes(w => [{ name:'匿名', text: wishText, when:'just now' }, ...w]);
            setWishText('');
          }} style={{ padding:'14px 28px', background: C_GOLD, color: C_PAPER,
                       border:'none', fontFamily:'"Noto Serif SC", serif',
                       fontSize: 13, letterSpacing:'0.3em', cursor:'pointer' }}>
            ✦ 寄出
          </button>
        </div>
      </section>

      <footer style={{ padding:'48px 80px', background: C_PAPER, borderTop:`1px solid ${C_INK}`,
                       display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div style={{ fontFamily:'"EB Garamond", serif', fontStyle:'italic',
                       fontSize: 18, color: C_INK }}>
          event horizon café · 视界
        </div>
        <div style={{ display:'flex', gap: 36, fontSize: 12, color: C_INK2, letterSpacing:'0.2em' }}>
          <span>天文系楼 1F · TUE–SUN 14:00–23:30</span>
          <span>WECHAT: ehc_observatory</span>
          <span>© 2026</span>
        </div>
      </footer>
    </div>
  );
}
Object.assign(window, { HomepageC, ConstellationHero });
